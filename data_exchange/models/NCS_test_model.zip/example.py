# -*- coding: utf-8 -*-
"""
example.py   NCS 充电桩项目 · 模型推理交接脚本（自包含）

只依赖: torch, numpy, pandas（CPU 即可运行，无需 GPU/训练代码）
用法:
    python example.py                                  # 用内置演示序列自测
    python example.py --pth model_all.pth --csv history.csv --steps 24
    history.csv 格式: 两列 ts,kwh （小时级历史负荷, 至少 512 行, ts 形如 2015-09-01 00:00:00）
输出: 与 history 同目录 forecast.csv（ts,forecast 两列）并在控制台打印 JSON。

模型口径（与训练一致）:
    输入 = 过去 512 小时 [kwh, hour_sin, hour_cos, dow_sin, dow_cos]（5 通道）
    输出 = 未来 24 小时逐小时负荷预测（kWh/h, 数值上等于该小时平均功率 kW）
"""
import argparse
import json
import math
import sys

import numpy as np
import pandas as pd
import torch
import torch.nn as nn


# ============================================================= 模型定义（与训练版 model.py 严格一致）
class CausalConv1d(nn.Module):
    def __init__(self, c_in, c_out, kernel, dilation):
        super().__init__()
        self.pad = (kernel - 1) * dilation
        self.conv = nn.Conv1d(c_in, c_out, kernel, dilation=dilation)

    def forward(self, x):                                # [B, C, L]
        x = nn.functional.pad(x, (self.pad, 0))
        return self.conv(x)


class SEGate(nn.Module):
    def __init__(self, ch, red=4):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(ch, max(ch // red, 4)), nn.GELU(),
                                 nn.Linear(max(ch // red, 4), ch))

    def forward(self, x):
        g = torch.sigmoid(self.net(x.mean(-1))).unsqueeze(-1)
        return x * g


class MultiScaleConv(nn.Module):
    def __init__(self, c_in, periods, kernel, ch, use_gate=True):
        super().__init__()
        self.branches = nn.ModuleList([
            nn.Sequential(CausalConv1d(c_in, ch, kernel, d), nn.GELU(),
                          SEGate(ch) if use_gate else nn.Identity(),
                          nn.Conv1d(ch, ch, 1)) for d in periods])
        self.fuse = nn.Conv1d(c_in + ch * len(periods), c_in, 1)
        self.norm = nn.LayerNorm(c_in)

    def forward(self, x):                                # [B, L, C]
        h = x.transpose(1, 2)
        out = self.fuse(torch.cat([h] + [b(h) for b in self.branches], dim=1)).transpose(1, 2)
        return self.norm(x + out)


class PosEncode(nn.Module):
    def __init__(self, d_model, max_len=4096):
        super().__init__()
        self.pe = nn.Parameter(torch.zeros(1, max_len, d_model))
        nn.init.trunc_normal_(self.pe, std=0.02)

    def forward(self, x):
        return x + self.pe[:, : x.size(1)]


class MultiScaleConvTransformer(nn.Module):
    def __init__(self, c_in, horizon, periods, mcfg, max_len=4096):
        super().__init__()
        self.horizon = horizon
        n_blk = mcfg.get("conv_blocks", 1)
        gate = mcfg.get("use_scale_gate", False)
        self.msconv = nn.Sequential(*[
            MultiScaleConv(c_in, periods, mcfg["conv_kernel"], mcfg["conv_channels"],
                           use_gate=gate) for _ in range(max(1, n_blk))])
        self.proj = nn.Linear(c_in, mcfg["d_model"])
        self.pos = PosEncode(mcfg["d_model"], max_len)
        enc = nn.TransformerEncoderLayer(mcfg["d_model"], mcfg["nhead"], mcfg["dim_ff"],
                                         mcfg["dropout"], batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(enc, mcfg["num_encoder_layers"])
        dec = nn.TransformerDecoderLayer(mcfg["d_model"], mcfg["nhead"], mcfg["dim_ff"],
                                         mcfg["dropout"], batch_first=True, norm_first=True)
        self.decoder = nn.TransformerDecoder(dec, mcfg["num_decoder_layers"])
        self.q_embed = nn.Embedding(horizon, mcfg["d_model"])
        self.q_cal = nn.Linear(4, mcfg["d_model"])
        self.head = nn.Linear(mcfg["d_model"], 1)

    def forward(self, x, cal=None):                      # x [B,L,C], cal [B,L+H,4]
        h = self.pos(self.proj(self.msconv(x)))
        memory = self.encoder(h)
        idx = x.size(1) - 1
        q = self.q_embed.weight.unsqueeze(0).expand(x.size(0), -1, -1)
        if cal is not None and cal.size(1) >= idx + 1 + self.horizon:
            q = q + self.q_cal(cal[:, idx + 1: idx + 1 + self.horizon, :])
        return self.head(self.decoder(q, memory)).squeeze(-1)   # [B, H]


# ============================================================= 特征与推理
def cal_rows(ts_list):
    """时刻序列 → 4 维日历特征 [hour_sin, hour_cos, dow_sin, dow_cos]（真星期，交接数据时间戳未脱敏）。"""
    out = []
    for t in pd.to_datetime(ts_list):
        h, d = t.hour, t.dayofweek
        out.append([math.sin(2 * math.pi * h / 24), math.cos(2 * math.pi * h / 24),
                    math.sin(2 * math.pi * d / 7), math.cos(2 * math.pi * d / 7)])
    return np.asarray(out, dtype=np.float32)


def build_input(kwh: np.ndarray, fut_ts, periods, lookback: int, mean: float, std: float):
    """kwh 历史(≥lookback+1 小时) → [1, L, 5] 输入 + [1, L+H, 4] 日历。
    目标通道用 checkpoint 内训练统计做 z 标准化(与训练分布严格一致)。"""
    kwh = np.asarray(kwh, dtype=np.float32)[-lookback - 24:]
    hist_ts = pd.date_range(end=fut_ts[0] - pd.Timedelta(hours=1),
                            periods=len(kwh), freq="h")
    cal = cal_rows(list(hist_ts) + list(fut_ts))         # [L+H, 4]
    tgt = ((kwh - mean) / std).reshape(-1, 1)
    x = np.concatenate([tgt, cal[: len(kwh)]], axis=1)   # [L, 5]
    return (torch.from_numpy(x[-lookback:]).float().unsqueeze(0),
            torch.from_numpy(cal).float().unsqueeze(0))


@torch.no_grad()
def forecast(pth_path: str, kwh: np.ndarray, start_ts, steps: int = 24):
    ck = torch.load(pth_path, map_location="cpu", weights_only=False)
    dcfg, mcfg = ck["data_cfg"], ck["model_cfg"]
    if dcfg.get("use_state_feats"):
        raise ValueError("该 checkpoint 使用状态特征通道, 本交接脚本仅支持标准 5 通道模型, 请重新导出权重")
    if dcfg.get("diff_target") or dcfg.get("log1p_target"):
        raise ValueError("该 checkpoint 为 diff/log1p 实验口径, 请使用水平值口径权重")
    horizon = dcfg["horizon"]
    periods = dcfg["periods"]
    lookback = dcfg["lookback"]
    model = MultiScaleConvTransformer(5, horizon, periods, mcfg)
    model.load_state_dict(ck["model_state"])
    model.eval()

    fut_ts = list(pd.date_range(start=start_ts, periods=steps, freq="h"))
    mean = float(ck["norm"]["mean"][0])                  # 训练时目标通道的归一化统计
    std = float(ck["norm"]["std"][0])
    preds = []
    hist = list(np.asarray(kwh, dtype=np.float64))
    done = 0
    while done < steps:                                  # 迭代外推: 按 horizon 分块滚动
        need = min(horizon, steps - done)
        x, cal = build_input(np.asarray(hist), fut_ts[done:], periods, lookback, mean, std)
        chunk = model(x, cal)[0].numpy()[:need]
        lvl = np.clip(chunk * std + mean, 0.0, None)     # 反归一化 + 非负
        preds.extend(lvl.tolist())
        hist.extend(lvl.tolist())
        done += need
    return [{"ts": str(t), "forecast": round(p, 3)} for t, p in zip(fut_ts, preds)]


def demo():
    """无输入文件时: 构造 30 天带日周期+噪声的演示序列自测链路。"""
    rng = np.random.default_rng(7)
    n = 24 * 30
    ts = pd.date_range("2015-09-01", periods=n, freq="h")
    kwh = np.clip(6 + 5 * np.sin(2 * np.pi * ts.hour / 24)
                  + 2 * np.sin(2 * np.pi * ts.dayofweek / 7)
                  + rng.normal(0, 1.5, n) + (rng.random(n) < 0.03) * 20, 0, None)
    return kwh, ts[-1] + pd.Timedelta(hours=1)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="充电负荷预测推理(交接用)")
    ap.add_argument("--pth", default="model_all.pth", help="模型权重路径")
    ap.add_argument("--csv", default=None, help="历史负荷 CSV(ts,kwh 两列, 小时级)")
    ap.add_argument("--steps", type=int, default=24, help="预测步数")
    a = ap.parse_args()

    if a.csv:
        h = pd.read_csv(a.csv, parse_dates=["ts"])
        kwh, next_ts = h["kwh"].values, h["ts"].max() + pd.Timedelta(hours=1)
    else:
        print("[warn] 未提供 --csv, 使用内置演示序列")
        kwh, next_ts = demo()
    res = forecast(a.pth, kwh, next_ts, a.steps)
    print(json.dumps({"next_steps": [r["forecast"] for r in res[:6]], "n": len(res)},
                     ensure_ascii=False))
    if a.csv:
        import os
        out = os.path.join(os.path.dirname(os.path.abspath(a.csv)), "forecast.csv")
        pd.DataFrame(res).to_csv(out, index=False)
        print("[out]", out)
