#!/bin/bash
set -Eeuo pipefail

ROOT=$(cd "$(dirname "$0")" && pwd)
RUN_USER=$(id -un)
UNIT_NAME=ncs-spark-pipeline.service
TEMPLATE="$ROOT/systemd/$UNIT_NAME.template"
TMP_UNIT=$(mktemp)
trap 'rm -f "$TMP_UNIT"' EXIT

command -v systemctl >/dev/null 2>&1 || { echo "当前系统没有systemd，无法安装开机服务。" >&2; exit 1; }
[[ -f "$TEMPLATE" ]] || { echo "缺少服务模板: $TEMPLATE" >&2; exit 1; }

sed -e "s|__RUN_USER__|$RUN_USER|g" -e "s|__PIPELINE_ROOT__|$ROOT|g" "$TEMPLATE" > "$TMP_UNIT"
chmod +x "$ROOT"/*.sh

echo "将为用户 $RUN_USER 安装虚拟机开机自启服务。首次安装需要输入sudo密码。"
if systemctl list-unit-files sshd.service --no-legend 2>/dev/null | grep -q '^sshd.service'; then
  sudo systemctl enable --now sshd.service
fi
for DB_SERVICE in mysqld.service mariadb.service; do
  if systemctl list-unit-files "$DB_SERVICE" --no-legend 2>/dev/null | grep -q "^$DB_SERVICE"; then
    sudo systemctl enable --now "$DB_SERVICE"
    break
  fi
done
sudo install -m 0644 "$TMP_UNIT" "/etc/systemd/system/$UNIT_NAME"
sudo systemctl daemon-reload
sudo systemctl enable --now "$UNIT_NAME"

echo "安装完成。以后启动虚拟机后会自动准备Hadoop/YARN/Metastore并检测数据变化。"
sudo systemctl status "$UNIT_NAME" --no-pager -l || true
echo "状态命令: bash $ROOT/status_autostart.sh"
