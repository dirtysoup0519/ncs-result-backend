#!/bin/bash
set -Eeuo pipefail

ROOT=$(cd "$(dirname "$0")" && pwd)
source "$ROOT/config.env"
INPUT_DIR=${1:-$INBOUND_DIR}
RUN_ID=$(date +%Y%m%d_%H%M%S)
RUN_LOG="$LOG_DIR/run_$RUN_ID.log"
LOCK_DIR="$STATE_DIR/pipeline.lock"
STAGE_OUT="${OUTPUT_DIR}.staging.$RUN_ID"
SCHEMA_MARKER="$STATE_DIR/schema_initialized_v24_orc"
BATCH_SQL="$STATE_DIR/full_refresh_$RUN_ID.hql"
EXPORT_STREAM="$STATE_DIR/export_stream_$RUN_ID.tsv"

mkdir -p "$STATE_DIR" "$LOG_DIR" "$LOAD_DIR" "$(dirname "$OUTPUT_DIR")"
if ! mkdir "$LOCK_DIR" 2>/dev/null; then
  echo "已有流水线正在运行: $LOCK_DIR" >&2
  exit 1
fi
cleanup() { rmdir "$LOCK_DIR" 2>/dev/null || true; }
trap cleanup EXIT
exec > >(tee -a "$RUN_LOG") 2>&1

run_stage() {
  local name=$1
  shift
  local started=$SECONDS
  echo "[$(date '+%F %T')] STAGE_START $name"
  "$@"
  echo "[$(date '+%F %T')] STAGE_DONE $name elapsed=$((SECONDS-started))s"
}

run_sql_batch() {
  case "$SQL_ENGINE" in
    spark)
      "$SPARK_SQL_BIN" \
        --master "$SPARK_MASTER" \
        --name "$SPARK_APP_NAME-$RUN_ID" \
        --silent \
        --conf spark.sql.cli.print.header=false \
        --conf spark.sql.adaptive.enabled=true \
        --conf spark.sql.shuffle.partitions="$SPARK_SQL_SHUFFLE_PARTITIONS" \
        --conf spark.default.parallelism="$SPARK_SQL_SHUFFLE_PARTITIONS" \
        --hiveconf hive.cli.print.header=false \
        --hivevar load_dir="$LOAD_DIR" \
        -f "$BATCH_SQL" > "$EXPORT_STREAM"
      ;;
    hive)
      "$HIVE_BIN" --silent \
        --hiveconf hive.cli.print.header=false \
        --hiveconf hive.fetch.task.conversion=more \
        --hivevar load_dir="$LOAD_DIR" \
        -f "$BATCH_SQL" > "$EXPORT_STREAM"
      ;;
    *)
      echo "不支持的SQL_ENGINE: $SQL_ENGINE（仅支持spark或hive）" >&2
      return 2
      ;;
  esac
}

echo "[$(date '+%F %T')] START run_id=$RUN_ID input=$INPUT_DIR"
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "找不到Python解释器: $PYTHON_BIN；请在config.env设置PYTHON_BIN" >&2
  exit 1
fi
case "$SQL_ENGINE" in
  spark)
    if ! command -v "$SPARK_SQL_BIN" >/dev/null 2>&1; then
      echo "找不到Spark SQL命令: $SPARK_SQL_BIN；请在config.env设置SPARK_SQL_BIN" >&2
      exit 1
    fi
    ;;
  hive)
    if ! command -v "$HIVE_BIN" >/dev/null 2>&1; then
      echo "找不到Hive命令: $HIVE_BIN；请在config.env设置HIVE_BIN" >&2
      exit 1
    fi
    ;;
  *)
    echo "不支持的SQL_ENGINE: $SQL_ENGINE（仅支持spark或hive）" >&2
    exit 2
    ;;
esac
JAVA_CLASSES=$(timeout 10 jps 2>/dev/null | awk 'NF >= 2 {print $2}' || true)
for daemon in $REQUIRED_DAEMONS; do
  if ! grep -qx "$daemon" <<< "$JAVA_CLASSES"; then
    echo "缺少Hadoop进程: $daemon" >&2
    echo "请改用：bash $ROOT/一键启动流水线.sh" >&2
    exit 1
  fi
done

run_stage validate_input "$PYTHON_BIN" "$ROOT/validate_input.py" "$INPUT_DIR"
cp -f "$INPUT_DIR/dsv13r2.csv" "$LOAD_DIR/dsv13r2.csv"
cp -f "$INPUT_DIR/nvv2t.csv" "$LOAD_DIR/nvv2t.csv"
cp -f "$INPUT_DIR/nvv2t_md_end.csv" "$LOAD_DIR/nvv2t_md_end.csv"

NEED_SCHEMA=0
if [ "${INITIALIZE_SCHEMA:-auto}" = "always" ] || { [ "${INITIALIZE_SCHEMA:-auto}" = "auto" ] && [ ! -f "$SCHEMA_MARKER" ]; }; then
  NEED_SCHEMA=1
  cp "$ROOT/sql/01_sim_create.hql" "$BATCH_SQL"
  cat "$ROOT/sql/02_sim_migrate_orc.hql" >> "$BATCH_SQL"
else
  echo "[$(date '+%F %T')] STAGE_SKIP initialize_schema (schema marker exists)"
  : > "$BATCH_SQL"
fi
mkdir -p "$STAGE_OUT"
cat "$ROOT/sql/03_sim_load.hql" \
    "$ROOT/sql/04_sim_dwd.hql" \
    "$ROOT/sql/05_sim_dws_ads.hql" \
    "$ROOT/sql/06_export_stream.hql" >> "$BATCH_SQL"

run_stage "${SQL_ENGINE}_full_refresh" run_sql_batch
rm -f "$BATCH_SQL"
if [ "$NEED_SCHEMA" -eq 1 ]; then
  touch "$SCHEMA_MARKER"
fi

run_stage collect_exports "$PYTHON_BIN" "$ROOT/split_export_stream.py" "$EXPORT_STREAM" "$STAGE_OUT"
rm -f "$EXPORT_STREAM"
run_stage build_ml_outputs "$PYTHON_BIN" "$ROOT/build_ml_outputs.py" "$INPUT_DIR" "$STAGE_OUT/ml"
run_stage build_partner_outputs "$PYTHON_BIN" "$ROOT/build_partner_outputs.py" "$INPUT_DIR" "$STAGE_OUT" "$STAGE_OUT/contract_v2" "$RUN_ID"
run_stage validate_output "$PYTHON_BIN" "$ROOT/validate_output.py" "$STAGE_OUT" "$STAGE_OUT/manifest.json"

if [ -d "$OUTPUT_DIR" ]; then
  mv "$OUTPUT_DIR" "${OUTPUT_DIR}.previous.$RUN_ID"
fi
mv "$STAGE_OUT" "$OUTPUT_DIR"
cp -f "$OUTPUT_DIR/manifest.json" "$STATE_DIR/last_success.json"
echo "[$(date '+%F %T')] SUCCESS output=$OUTPUT_DIR manifest=$OUTPUT_DIR/manifest.json"
echo "[$(date '+%F %T')] TOTAL elapsed=${SECONDS}s"
