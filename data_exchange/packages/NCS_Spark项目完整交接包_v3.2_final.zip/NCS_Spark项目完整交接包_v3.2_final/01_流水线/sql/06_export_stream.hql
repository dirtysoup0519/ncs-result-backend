-- 在同一SQL会话流式输出已物化结果，避免每个文件再启动一个计算作业。
SET spark.sql.cli.print.header=false;

SELECT '__NCS_BEGIN__kpi_total';
SELECT * FROM ncs_sim_ads.ads_kpi_total;
SELECT '__NCS_END__kpi_total';

SELECT '__NCS_BEGIN__revenue_trend';
SELECT * FROM ncs_sim_ads.ads_revenue_trend;
SELECT '__NCS_END__revenue_trend';

SELECT '__NCS_BEGIN__revenue_monthly';
SELECT * FROM ncs_sim_ads.ads_revenue_monthly;
SELECT '__NCS_END__revenue_monthly';

SELECT '__NCS_BEGIN__station_top10';
SELECT * FROM ncs_sim_ads.ads_station_top10;
SELECT '__NCS_END__station_top10';

SELECT '__NCS_BEGIN__platform_stat';
SELECT * FROM ncs_sim_ads.ads_platform_stat;
SELECT '__NCS_END__platform_stat';

SELECT '__NCS_BEGIN__hourly_stat';
SELECT * FROM ncs_sim_ads.ads_hourly_stat;
SELECT '__NCS_END__hourly_stat';

SELECT '__NCS_BEGIN__order_daily';
SELECT * FROM ncs_sim_dws.dws_order_daily;
SELECT '__NCS_END__order_daily';

SELECT '__NCS_BEGIN__process_daily';
SELECT * FROM ncs_sim_dws.dws_process_daily;
SELECT '__NCS_END__process_daily';

SELECT '__NCS_BEGIN__station_hour_heatmap';
SELECT * FROM ncs_sim_ads.ads_station_hour_heatmap;
SELECT '__NCS_END__station_hour_heatmap';

SELECT '__NCS_BEGIN__duration_distribution';
SELECT * FROM ncs_sim_ads.ads_duration_distribution;
SELECT '__NCS_END__duration_distribution';

SELECT '__NCS_BEGIN__workday_weekend';
SELECT * FROM ncs_sim_ads.ads_workday_weekend;
SELECT '__NCS_END__workday_weekend';

SELECT '__NCS_BEGIN__workday_hour_compare';
SELECT * FROM ncs_sim_ads.ads_workday_hour_compare;
SELECT '__NCS_END__workday_hour_compare';

SELECT '__NCS_BEGIN__charge_type_stat';
SELECT * FROM ncs_sim_ads.ads_charge_type_stat;
SELECT '__NCS_END__charge_type_stat';

SELECT '__NCS_BEGIN__station_type_cross';
SELECT * FROM ncs_sim_ads.ads_station_type_cross;
SELECT '__NCS_END__station_type_cross';

SELECT '__NCS_BEGIN__monthly_comparison';
SELECT * FROM ncs_sim_ads.ads_monthly_comparison;
SELECT '__NCS_END__monthly_comparison';
