-- v2.4 一次性存储格式迁移：ODS继续保留TEXTFILE，派生层改为ORC+SNAPPY。
-- 派生表全部可由ODS重建；首次升级运行时删除旧PARQUET定义，随后由04/05脚本重建。
DROP TABLE IF EXISTS ncs_sim_dwd.dwd_charging_order;
DROP TABLE IF EXISTS ncs_sim_dwd.dwd_charging_process;
DROP TABLE IF EXISTS ncs_sim_dwd.dwd_charging_station_meta;

DROP TABLE IF EXISTS ncs_sim_dws.dws_order_daily;
DROP TABLE IF EXISTS ncs_sim_dws.dws_order_station_daily;
DROP TABLE IF EXISTS ncs_sim_dws.dws_order_hourly;
DROP TABLE IF EXISTS ncs_sim_dws.dws_process_daily;
DROP TABLE IF EXISTS ncs_sim_dws.dws_order_station_hourly;

DROP TABLE IF EXISTS ncs_sim_ads.ads_kpi_total;
DROP TABLE IF EXISTS ncs_sim_ads.ads_revenue_trend;
DROP TABLE IF EXISTS ncs_sim_ads.ads_station_top10;
DROP TABLE IF EXISTS ncs_sim_ads.ads_platform_stat;
DROP TABLE IF EXISTS ncs_sim_ads.ads_hourly_stat;
DROP TABLE IF EXISTS ncs_sim_ads.ads_revenue_monthly;
DROP TABLE IF EXISTS ncs_sim_ads.ads_station_hour_heatmap;
DROP TABLE IF EXISTS ncs_sim_ads.ads_duration_distribution;
DROP TABLE IF EXISTS ncs_sim_ads.ads_workday_weekend;
DROP TABLE IF EXISTS ncs_sim_ads.ads_monthly_comparison;
DROP TABLE IF EXISTS ncs_sim_ads.ads_workday_hour_compare;
DROP TABLE IF EXISTS ncs_sim_ads.ads_charge_type_stat;
DROP TABLE IF EXISTS ncs_sim_ads.ads_station_type_cross;
