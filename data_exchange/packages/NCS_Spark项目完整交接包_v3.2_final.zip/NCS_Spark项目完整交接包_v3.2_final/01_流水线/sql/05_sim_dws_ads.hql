-- =============================================================
-- 模拟库平行版（ncs_sim_*）：正式库 ncs_* 不受影响
-- 数据源：gen_sim_data.py 生成的模拟 CSV（放 /home/hadoop/simdata/）
-- 由正式版脚本自动替换生成，勿手工编辑
-- =============================================================
-- =============================================================
-- 05_build_dws_ads.hql   NCS 项目：DWD -> DWS/ADS 聚合层（真实数据版）
-- 前置：DWD 三表已生成（行数 3395 / 1594 / 105）
-- 执行：hive -f /home/hadoop/05_build_dws_ads.hql
-- DWS（明细汇总层）：按日/站点/小时聚合
-- ADS（指标应用层）：大屏指标表
-- 说明：脱敏年份已按上游交接契约在DWD统一为2019，时间全部有效，
--       聚合统计全量数据（不排除）
-- =============================================================
-- ================= DWS 层 =================
USE ncs_sim_dws;

-- 1) 按日聚合：营收趋势
CREATE TABLE IF NOT EXISTS dws_order_daily (
  stat_date STRING,
  order_cnt BIGINT,
  total_kwh DOUBLE,
  total_fees DOUBLE,
  total_charge_hours DOUBLE,
  user_cnt BIGINT
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE dws_order_daily
SELECT created_date,
       COUNT(*),
       ROUND(SUM(kwh_total),2),
       ROUND(SUM(charging_fees),2),
       ROUND(SUM(charge_hours),2),
       COUNT(DISTINCT user_id)
FROM ncs_sim_dwd.dwd_charging_order
GROUP BY created_date;

-- 2) 按日+站点聚合：站点分析
CREATE TABLE IF NOT EXISTS dws_order_station_daily (
  stat_date STRING,
  station_id STRING,
  order_cnt BIGINT,
  total_kwh DOUBLE,
  total_fees DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE dws_order_station_daily
SELECT created_date, station_id, COUNT(*), ROUND(SUM(kwh_total),2), ROUND(SUM(charging_fees),2)
FROM ncs_sim_dwd.dwd_charging_order
GROUP BY created_date, station_id;

-- 3) 按小时聚合：24h 时段分布
CREATE TABLE IF NOT EXISTS dws_order_hourly (
  stat_hour INT,
  order_cnt BIGINT,
  total_kwh DOUBLE,
  total_fees DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE dws_order_hourly
SELECT created_hour, COUNT(*), ROUND(SUM(kwh_total),2), ROUND(SUM(charging_fees),2)
FROM ncs_sim_dwd.dwd_charging_order
GROUP BY created_hour;

-- 4) 充电过程按日聚合：监测指标
CREATE TABLE IF NOT EXISTS dws_process_daily (
  stat_date STRING,
  record_cnt BIGINT,
  session_cnt BIGINT,
  avg_soc DOUBLE,
  max_soc DOUBLE,
  min_soc DOUBLE,
  avg_current DOUBLE,
  avg_pack_voltage DOUBLE,
  avg_max_temp DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE dws_process_daily
SELECT record_date,
       COUNT(*),
       COUNT(DISTINCT esd),
       ROUND(AVG(soc),2),
       ROUND(MAX(soc),2),
       ROUND(MIN(soc),2),
       ROUND(AVG(charge_current),2),
       ROUND(AVG(pack_voltage),2),
       ROUND(AVG(max_temperature),2)
FROM ncs_sim_dwd.dwd_charging_process
GROUP BY record_date;

-- ================= ADS 层 =================
USE ncs_sim_ads;

-- 1) 总 KPI 指标卡
CREATE TABLE IF NOT EXISTS ads_kpi_total (
  total_order_cnt BIGINT,
  total_fees DOUBLE,
  total_kwh DOUBLE,
  total_user_cnt BIGINT,
  total_station_cnt BIGINT,
  avg_fee_per_order DOUBLE,
  avg_kwh_per_order DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE ads_kpi_total
SELECT COUNT(*),
       ROUND(SUM(charging_fees),2),
       ROUND(SUM(kwh_total),2),
       COUNT(DISTINCT user_id),
       COUNT(DISTINCT station_id),
       ROUND(SUM(charging_fees)/COUNT(*),2),
       ROUND(SUM(kwh_total)/COUNT(*),2)
FROM ncs_sim_dwd.dwd_charging_order;

-- 2) 营收趋势（全部日期，前端可自行截取近7/30日）
CREATE TABLE IF NOT EXISTS ads_revenue_trend (
  stat_date STRING,
  order_cnt BIGINT,
  total_fees DOUBLE,
  total_kwh DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE ads_revenue_trend
SELECT stat_date, order_cnt, total_fees, total_kwh
FROM ncs_sim_dws.dws_order_daily;

-- 3) 站点 TOP10（按营收）
CREATE TABLE IF NOT EXISTS ads_station_top10 (
  station_id STRING,
  station_name STRING,
  location_id STRING,
  order_cnt BIGINT,
  total_fees DOUBLE,
  total_kwh DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE ads_station_top10
SELECT a.station_id, b.station_name, b.location_id,
       a.order_cnt, a.total_fees, a.total_kwh
FROM (
  SELECT station_id, COUNT(*) order_cnt, ROUND(SUM(charging_fees),2) total_fees, ROUND(SUM(kwh_total),2) total_kwh
  FROM ncs_sim_dwd.dwd_charging_order
  GROUP BY station_id
  ORDER BY SUM(charging_fees) DESC
  LIMIT 10
) a
LEFT JOIN ncs_sim_dwd.dwd_charging_station_meta b ON a.station_id = b.station_id;

-- 4) 平台占比
CREATE TABLE IF NOT EXISTS ads_platform_stat (
  platform STRING,
  order_cnt BIGINT,
  total_fees DOUBLE,
  fee_ratio DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE ads_platform_stat
SELECT p.platform, p.order_cnt, p.total_fees,
       ROUND(p.total_fees / SUM(p.total_fees) OVER () * 100, 2)
FROM (
  SELECT platform, COUNT(*) order_cnt, ROUND(SUM(charging_fees),2) total_fees
  FROM ncs_sim_dwd.dwd_charging_order
  GROUP BY platform
) p;

-- 5) 24h 时段分布
CREATE TABLE IF NOT EXISTS ads_hourly_stat (
  stat_hour INT,
  order_cnt BIGINT,
  total_kwh DOUBLE,
  total_fees DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE ads_hourly_stat
SELECT stat_hour, order_cnt, total_kwh, total_fees
FROM ncs_sim_dws.dws_order_hourly;

-- 6) 月度营收聚合（大屏月趋势）
CREATE TABLE IF NOT EXISTS ads_revenue_monthly (
  stat_month STRING,
  order_cnt BIGINT,
  total_fees DOUBLE,
  total_kwh DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE ads_revenue_monthly
SELECT substr(stat_date,1,7),
       SUM(order_cnt),
       ROUND(SUM(total_fees),2),
       ROUND(SUM(total_kwh),2)
FROM ncs_sim_dws.dws_order_daily
GROUP BY substr(stat_date,1,7);

-- ================= 大屏补充指标 =================

USE ncs_sim_dws;

-- 5) 站点×小时聚合：热力图
CREATE TABLE IF NOT EXISTS dws_order_station_hourly (
  station_id STRING,
  stat_hour INT,
  order_cnt BIGINT,
  total_kwh DOUBLE,
  total_fees DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE dws_order_station_hourly
SELECT station_id,
       created_hour,
       COUNT(*),
       ROUND(SUM(kwh_total),2),
       ROUND(SUM(charging_fees),2)
FROM ncs_sim_dwd.dwd_charging_order
GROUP BY station_id, created_hour;

USE ncs_sim_ads;

-- 7) 站点×小时热力图输出
CREATE TABLE IF NOT EXISTS ads_station_hour_heatmap (
  station_id STRING,
  station_name STRING,
  stat_hour INT,
  order_cnt BIGINT,
  total_kwh DOUBLE,
  total_fees DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE ads_station_hour_heatmap
SELECT h.station_id,
       s.station_name,
       h.stat_hour,
       h.order_cnt,
       h.total_kwh,
       h.total_fees
FROM ncs_sim_dws.dws_order_station_hourly h
LEFT JOIN ncs_sim_dwd.dwd_charging_station_meta s
  ON h.station_id = s.station_id;

-- 8) 充电时长分布
CREATE TABLE IF NOT EXISTS ads_duration_distribution (
  bucket_order INT,
  duration_bucket STRING,
  order_cnt BIGINT,
  order_ratio DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE ads_duration_distribution
SELECT bucket_order,
       duration_bucket,
       order_cnt,
       ROUND(order_cnt * 100.0 / SUM(order_cnt) OVER (), 2) AS order_ratio
FROM (
  SELECT bucket_order,
         duration_bucket,
         COUNT(*) AS order_cnt
  FROM (
    SELECT CASE
           WHEN charge_hours < 1 THEN 1
           WHEN charge_hours < 2 THEN 2
           WHEN charge_hours < 3 THEN 3
           ELSE 4
         END AS bucket_order,
         CASE
           WHEN charge_hours < 1 THEN '0-1h'
           WHEN charge_hours < 2 THEN '1-2h'
           WHEN charge_hours < 3 THEN '2-3h'
           ELSE '3h+'
         END AS duration_bucket
    FROM ncs_sim_dwd.dwd_charging_order
  ) bucketed
  GROUP BY bucket_order, duration_bucket
) counted;

-- 9) 工作日与周末对比
CREATE TABLE IF NOT EXISTS ads_workday_weekend (
  day_type STRING,
  order_cnt BIGINT,
  total_kwh DOUBLE,
  total_fees DOUBLE,
  avg_charge_hours DOUBLE,
  user_cnt BIGINT
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE ads_workday_weekend
SELECT CASE WHEN weekday IN ('Sat','Sun') THEN 'weekend' ELSE 'workday' END,
       COUNT(*),
       ROUND(SUM(kwh_total),2),
       ROUND(SUM(charging_fees),2),
       ROUND(AVG(charge_hours),2),
       COUNT(DISTINCT user_id)
FROM ncs_sim_dwd.dwd_charging_order
GROUP BY CASE WHEN weekday IN ('Sat','Sun') THEN 'weekend' ELSE 'workday' END;

-- 10) 工作日/周末 × 小时：双维度负荷对比
CREATE TABLE IF NOT EXISTS ads_workday_hour_compare (
  day_type STRING,
  stat_hour INT,
  order_cnt BIGINT,
  total_kwh DOUBLE,
  total_fees DOUBLE,
  avg_charge_hours DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE ads_workday_hour_compare
SELECT CASE WHEN weekday IN ('Sat','Sun') THEN 'weekend' ELSE 'workday' END,
       created_hour,
       COUNT(*),
       ROUND(SUM(kwh_total),2),
       ROUND(SUM(charging_fees),2),
       ROUND(AVG(charge_hours),2)
FROM ncs_sim_dwd.dwd_charging_order
GROUP BY CASE WHEN weekday IN ('Sat','Sun') THEN 'weekend' ELSE 'workday' END,
         created_hour;

-- 11) 桩型对比：交流/直流/交直流一体桩
CREATE TABLE IF NOT EXISTS ads_charge_type_stat (
  facility_type INT,
  charge_type STRING,
  order_cnt BIGINT,
  total_kwh DOUBLE,
  total_fees DOUBLE,
  avg_charge_hours DOUBLE,
  order_ratio DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE ads_charge_type_stat
SELECT facility_type,
       charge_type,
       order_cnt,
       total_kwh,
       total_fees,
       avg_charge_hours,
       ROUND(order_cnt * 100.0 / SUM(order_cnt) OVER (), 2)
FROM (
  SELECT facility_type,
         CASE facility_type
           WHEN 1 THEN 'AC'
           WHEN 2 THEN 'DC'
           WHEN 3 THEN 'AC_DC'
           ELSE 'OTHER'
         END AS charge_type,
         COUNT(*) AS order_cnt,
         ROUND(SUM(kwh_total),2) AS total_kwh,
         ROUND(SUM(charging_fees),2) AS total_fees,
         ROUND(AVG(charge_hours),2) AS avg_charge_hours
  FROM ncs_sim_dwd.dwd_charging_order
  GROUP BY facility_type
) grouped;

-- 12) 站点 × 桩型：双维度交叉分析
CREATE TABLE IF NOT EXISTS ads_station_type_cross (
  station_id STRING,
  station_name STRING,
  facility_type INT,
  charge_type STRING,
  order_cnt BIGINT,
  total_kwh DOUBLE,
  total_fees DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE ads_station_type_cross
SELECT o.station_id,
       s.station_name,
       o.facility_type,
       CASE o.facility_type
         WHEN 1 THEN 'AC'
         WHEN 2 THEN 'DC'
         WHEN 3 THEN 'AC_DC'
         ELSE 'OTHER'
       END,
       COUNT(*),
       ROUND(SUM(o.kwh_total),2),
       ROUND(SUM(o.charging_fees),2)
FROM ncs_sim_dwd.dwd_charging_order o
LEFT JOIN ncs_sim_dwd.dwd_charging_station_meta s
  ON o.station_id = s.station_id
GROUP BY o.station_id,
         s.station_name,
         o.facility_type,
         CASE o.facility_type
           WHEN 1 THEN 'AC'
           WHEN 2 THEN 'DC'
           WHEN 3 THEN 'AC_DC'
           ELSE 'OTHER'
         END;

-- 13) 月度环比：本月与上月比较
CREATE TABLE IF NOT EXISTS ads_monthly_comparison (
  stat_month STRING,
  order_cnt BIGINT,
  total_kwh DOUBLE,
  total_fees DOUBLE,
  user_cnt BIGINT,
  station_cnt BIGINT,
  order_mom_pct DOUBLE,
  kwh_mom_pct DOUBLE,
  fees_mom_pct DOUBLE,
  user_mom_pct DOUBLE,
  station_mom_pct DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE ads_monthly_comparison
SELECT stat_month,
       order_cnt,
       total_kwh,
       total_fees,
       user_cnt,
       station_cnt,
       CASE WHEN prev_order_cnt IS NULL OR prev_order_cnt = 0 THEN NULL ELSE ROUND((order_cnt-prev_order_cnt)*100.0/prev_order_cnt,2) END,
       CASE WHEN prev_total_kwh IS NULL OR prev_total_kwh = 0 THEN NULL ELSE ROUND((total_kwh-prev_total_kwh)*100.0/prev_total_kwh,2) END,
       CASE WHEN prev_total_fees IS NULL OR prev_total_fees = 0 THEN NULL ELSE ROUND((total_fees-prev_total_fees)*100.0/prev_total_fees,2) END,
       CASE WHEN prev_user_cnt IS NULL OR prev_user_cnt = 0 THEN NULL ELSE ROUND((user_cnt-prev_user_cnt)*100.0/prev_user_cnt,2) END,
       CASE WHEN prev_station_cnt IS NULL OR prev_station_cnt = 0 THEN NULL ELSE ROUND((station_cnt-prev_station_cnt)*100.0/prev_station_cnt,2) END
FROM (
  SELECT stat_month,
         order_cnt,
         total_kwh,
         total_fees,
         user_cnt,
         station_cnt,
         LAG(order_cnt) OVER (ORDER BY stat_month) AS prev_order_cnt,
         LAG(total_kwh) OVER (ORDER BY stat_month) AS prev_total_kwh,
         LAG(total_fees) OVER (ORDER BY stat_month) AS prev_total_fees,
         LAG(user_cnt) OVER (ORDER BY stat_month) AS prev_user_cnt,
         LAG(station_cnt) OVER (ORDER BY stat_month) AS prev_station_cnt
  FROM (
    SELECT SUBSTR(created_date,1,7) AS stat_month,
           COUNT(*) AS order_cnt,
           ROUND(SUM(kwh_total),2) AS total_kwh,
           ROUND(SUM(charging_fees),2) AS total_fees,
           COUNT(DISTINCT user_id) AS user_cnt,
           COUNT(DISTINCT station_id) AS station_cnt
    FROM ncs_sim_dwd.dwd_charging_order
    GROUP BY SUBSTR(created_date,1,7)
  ) monthly
) compared;

-- 教学验收要求的五张DWS主题表，统一读取宽明细 dwd_charge_detail。
CREATE TABLE IF NOT EXISTS dws_station_agg (
  station_id STRING, station_name STRING, address STRING,
  total_sessions BIGINT, total_kwh DOUBLE, total_fee DOUBLE,
  avg_duration DOUBLE, device_count INT
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');
INSERT OVERWRITE TABLE dws_station_agg
SELECT d.station_id,d.station_name,d.address,COUNT(*),ROUND(SUM(d.kwh),2),
       ROUND(SUM(d.charge_fee),2),ROUND(AVG(d.duration_hrs),2),MAX(s.device_count)
FROM ncs_sim_dwd.dwd_charge_detail d
LEFT JOIN ncs_sim_dwd.dwd_charging_station_meta s ON d.station_id=s.station_id
GROUP BY d.station_id,d.station_name,d.address;

CREATE TABLE IF NOT EXISTS dws_user_agg (
  user_id STRING,total_sessions BIGINT,total_kwh DOUBLE,
  total_fee DOUBLE,avg_duration DOUBLE,main_platform STRING
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');
INSERT OVERWRITE TABLE dws_user_agg
SELECT b.user_id,b.total_sessions,b.total_kwh,b.total_fee,b.avg_duration,p.platform
FROM (
  SELECT user_id,COUNT(*) total_sessions,ROUND(SUM(kwh),2) total_kwh,
         ROUND(SUM(charge_fee),2) total_fee,ROUND(AVG(duration_hrs),2) avg_duration
  FROM ncs_sim_dwd.dwd_charge_detail GROUP BY user_id
) b
LEFT JOIN (
  SELECT user_id,platform FROM (
    SELECT user_id,platform,COUNT(*) platform_sessions,
           ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY COUNT(*) DESC,platform) platform_rank
    FROM ncs_sim_dwd.dwd_charge_detail GROUP BY user_id,platform
  ) ranked_platform WHERE platform_rank=1
) p ON b.user_id=p.user_id;

CREATE TABLE IF NOT EXISTS dws_hour_agg (
  start_hour INT,total_sessions BIGINT,total_kwh DOUBLE,total_fee DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');
INSERT OVERWRITE TABLE dws_hour_agg
SELECT start_hour,COUNT(*),ROUND(SUM(kwh),2),ROUND(SUM(charge_fee),2)
FROM ncs_sim_dwd.dwd_charge_detail GROUP BY start_hour;

CREATE TABLE IF NOT EXISTS dws_dim_agg (
  dim_type STRING,dim_value STRING,total_sessions BIGINT,total_kwh DOUBLE,total_fee DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');
INSERT OVERWRITE TABLE dws_dim_agg
SELECT 'platform',platform,COUNT(*),ROUND(SUM(kwh),2),ROUND(SUM(charge_fee),2)
FROM ncs_sim_dwd.dwd_charge_detail GROUP BY platform
UNION ALL
SELECT 'gun_type',gun_type,COUNT(*),ROUND(SUM(kwh),2),ROUND(SUM(charge_fee),2)
FROM ncs_sim_dwd.dwd_charge_detail GROUP BY gun_type
UNION ALL
SELECT 'weekday',weekday,COUNT(*),ROUND(SUM(kwh),2),ROUND(SUM(charge_fee),2)
FROM ncs_sim_dwd.dwd_charge_detail GROUP BY weekday
UNION ALL
SELECT 'weekend',CASE WHEN is_weekend=1 THEN 'weekend' ELSE 'workday' END,
       COUNT(*),ROUND(SUM(kwh),2),ROUND(SUM(charge_fee),2)
FROM ncs_sim_dwd.dwd_charge_detail
GROUP BY CASE WHEN is_weekend=1 THEN 'weekend' ELSE 'workday' END
UNION ALL
SELECT 'soc_level',start_soc_level,COUNT(*),ROUND(SUM(kwh),2),ROUND(SUM(charge_fee),2)
FROM ncs_sim_dwd.dwd_charge_detail WHERE start_soc_level IS NOT NULL GROUP BY start_soc_level;

CREATE TABLE IF NOT EXISTS dws_bms_agg (
  start_soc_level STRING,total_sessions BIGINT,avg_soc DOUBLE,
  avg_pack_voltage DOUBLE,avg_charge_current DOUBLE,max_temperature DOUBLE,min_temperature DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');
INSERT OVERWRITE TABLE dws_bms_agg
SELECT start_soc_level,COUNT(*),ROUND(AVG(soc),2),ROUND(AVG(pack_voltage),2),
       ROUND(AVG(charge_current),2),ROUND(MAX(max_temperature),2),ROUND(MIN(min_temperature),2)
FROM ncs_sim_dwd.dwd_charge_detail WHERE soc IS NOT NULL GROUP BY start_soc_level;

-- 生产流水线不额外启动COUNT验证作业；文件由validate_output.py统一校验。
