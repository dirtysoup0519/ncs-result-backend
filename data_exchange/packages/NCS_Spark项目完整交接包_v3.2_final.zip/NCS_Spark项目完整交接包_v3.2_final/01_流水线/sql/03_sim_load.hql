-- =============================================================
-- 模拟库平行版（ncs_sim_*）：正式库 ncs_* 不受影响
-- 数据源：gen_sim_data.py 生成的模拟 CSV（放 /home/hadoop/simdata/）
-- 由正式版脚本自动替换生成，勿手工编辑
-- =============================================================
-- =============================================================
-- 03_load_ods.hql   NCS 项目：导入 CSV 数据到 ODS 层
-- 前置：三个 CSV 已上传到 node100 的 /home/hadoop/simdata/
-- 执行：hive -f /home/hadoop/03_load_ods.hql
-- 注意：LOAD DATA LOCAL INPATH 会把文件"移动"（非复制）到 HDFS
--       /home/hadoop/simdata/ 下的源文件将被移走
-- =============================================================
USE ncs_sim_ods;

LOAD DATA LOCAL INPATH '${hivevar:load_dir}/dsv13r2.csv' OVERWRITE INTO TABLE ods_charging_process;
LOAD DATA LOCAL INPATH '${hivevar:load_dir}/nvv2t.csv' OVERWRITE INTO TABLE ods_charging_order;
LOAD DATA LOCAL INPATH '${hivevar:load_dir}/nvv2t_md_end.csv' OVERWRITE INTO TABLE ods_charging_station_meta;

-- 生产流水线不单独启动COUNT验证作业；输入校验及最终汇总校验统一负责验收。
