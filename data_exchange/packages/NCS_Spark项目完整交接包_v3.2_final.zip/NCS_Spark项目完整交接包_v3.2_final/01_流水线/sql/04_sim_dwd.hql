-- =============================================================
-- 模拟库平行版（ncs_sim_*）：正式库 ncs_* 不受影响
-- 数据源：gen_sim_data.py 生成的模拟 CSV（放 /home/hadoop/simdata/）
-- 由正式版脚本自动替换生成，勿手工编辑
-- =============================================================
-- =============================================================
-- 04_build_dwd.hql   NCS 项目：ODS -> DWD 清洗层（真实数据版）
-- 前置：ODS 三表已导入老师真实数据（行数 3395 / 1594 / 105）
-- 执行：hive -f /home/hadoop/04_build_dwd.hql
-- 清洗内容：
--   1) created/ended 脱敏年份(0014/0015) -> 按上游交接口径统一为 2019
--      ODS 保留原始0014/0015；DWD只替换年份，月份日时分秒保持不变
--      并标记 is_abnormal=1，保留数据质量可追溯
--   2) record_time 原始为科学计数法(2.02E+13)且精度丢失(全表同值)，
--      无法解析为有效时间 -> 通过 esd 关联订单表(esd=sessionId)，
--      用订单修复后的 created 时间作为监测记录时间
--   3) 字符串字段 -> 数值类型(DOUBLE/INT)
--   4) DWD剔除业务无效订单：零/负电量、零/负时长、时长>24h、
--      平均功率>120kW、结束早于开始。ODS仍完整保留，便于审计追溯。
-- =============================================================
USE ncs_sim_dwd;

-- 1) 订单明细 DWD
CREATE TABLE IF NOT EXISTS dwd_charging_order (
  session_id STRING,
  kwh_total DOUBLE,
  charging_fees DOUBLE,
  created_ts TIMESTAMP,
  ended_ts TIMESTAMP,
  created_date STRING,
  created_hour INT,
  start_hour INT,
  end_hour INT,
  charge_hours DOUBLE,
  weekday STRING,
  platform STRING,
  user_id STRING,
  station_id STRING,
  location_id STRING,
  manager_vehicle INT,
  facility_type INT,
  is_abnormal INT,
  mon INT, tues INT, wed INT, thurs INT, fri INT, sat INT, sun INT
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE dwd_charging_order
SELECT
  sessionId,
  cast(kwhTotal AS DOUBLE),
  cast(charging_fees AS DOUBLE),
  cast(from_unixtime(unix_timestamp(CASE WHEN created RLIKE '^00[0-9][0-9]-' THEN concat('2019',substr(created,5)) ELSE created END,'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd HH:mm:ss') AS TIMESTAMP),
  cast(from_unixtime(unix_timestamp(CASE WHEN ended RLIKE '^00[0-9][0-9]-' THEN concat('2019',substr(ended,5)) ELSE ended END,'yyyy-MM-dd HH:mm:ss'),'yyyy-MM-dd HH:mm:ss') AS TIMESTAMP),
  substr(CASE WHEN created RLIKE '^00[0-9][0-9]-' THEN concat('2019',substr(created,5)) ELSE created END,1,10),
  cast(substr(CASE WHEN created RLIKE '^00[0-9][0-9]-' THEN concat('2019',substr(created,5)) ELSE created END,12,2) AS INT),
  cast(startTime AS INT),
  cast(endTime AS INT),
  cast(chargeTimeHrs AS DOUBLE),
  weekday,
  platform,
  userId,
  stationId,
  locationId,
  cast(managerVehicle AS INT),
  cast(facilityType AS INT),
  CASE WHEN created LIKE '001%' THEN 1 ELSE 0 END,
  cast(Mon AS INT), cast(Tues AS INT), cast(Wed AS INT),
  cast(Thurs AS INT), cast(Fri AS INT), cast(Sat AS INT), cast(Sun AS INT)
FROM (
  SELECT src.*,
         ROW_NUMBER() OVER (
           PARTITION BY sessionId
           ORDER BY
             (CASE WHEN userId IS NOT NULL AND TRIM(userId) <> '' THEN 1 ELSE 0 END
              + CASE WHEN stationId IS NOT NULL AND TRIM(stationId) <> '' THEN 1 ELSE 0 END
              + CASE WHEN locationId IS NOT NULL AND TRIM(locationId) <> '' THEN 1 ELSE 0 END
              + CASE WHEN platform IS NOT NULL AND TRIM(platform) <> '' THEN 1 ELSE 0 END
              + CASE WHEN weekday IS NOT NULL AND TRIM(weekday) <> '' THEN 1 ELSE 0 END) DESC,
             unix_timestamp(CASE WHEN ended RLIKE '^00[0-9][0-9]-' THEN concat('2019',substr(ended,5)) ELSE ended END,'yyyy-MM-dd HH:mm:ss') DESC,
             unix_timestamp(CASE WHEN created RLIKE '^00[0-9][0-9]-' THEN concat('2019',substr(created,5)) ELSE created END,'yyyy-MM-dd HH:mm:ss') DESC,
             cast(kwhTotal AS DOUBLE) DESC
         ) AS dedup_rank
  FROM ncs_sim_ods.ods_charging_order src
  WHERE sessionId IS NOT NULL AND TRIM(sessionId) <> '' AND sessionId <> 'sessionId'
    AND cast(kwhTotal AS DOUBLE) > 0
    AND cast(chargeTimeHrs AS DOUBLE) > 0
    AND cast(chargeTimeHrs AS DOUBLE) <= 24
    AND cast(kwhTotal AS DOUBLE) / cast(chargeTimeHrs AS DOUBLE) <= 120
    AND unix_timestamp(CASE WHEN ended RLIKE '^00[0-9][0-9]-' THEN concat('2019',substr(ended,5)) ELSE ended END,'yyyy-MM-dd HH:mm:ss')
        >= unix_timestamp(CASE WHEN created RLIKE '^00[0-9][0-9]-' THEN concat('2019',substr(created,5)) ELSE created END,'yyyy-MM-dd HH:mm:ss')
) dedup
WHERE dedup_rank = 1;

-- 2) 充电过程监测 DWD
--    record_time 原始精度丢失 -> 关联订单表修复时间(esd=sessionId)
CREATE TABLE IF NOT EXISTS dwd_charging_process (
  esd STRING,
  record_time_ts TIMESTAMP,
  record_date STRING,
  record_hour INT,
  soc DOUBLE,
  pack_voltage DOUBLE,
  charge_current DOUBLE,
  max_cell_voltage DOUBLE,
  min_cell_voltage DOUBLE,
  max_temperature DOUBLE,
  min_temperature DOUBLE,
  available_energy DOUBLE,
  available_capacity DOUBLE
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE dwd_charging_process
SELECT
  p.esd,
  o.created_ts,
  o.created_date,
  o.created_hour,
  cast(p.soc AS DOUBLE),
  cast(p.pack_voltage AS DOUBLE),
  cast(p.charge_current AS DOUBLE),
  cast(p.max_cell_voltage AS DOUBLE),
  cast(p.min_cell_voltage AS DOUBLE),
  cast(p.max_temperature AS DOUBLE),
  cast(p.min_temperature AS DOUBLE),
  cast(p.available_energy AS DOUBLE),
  cast(p.available_capacity AS DOUBLE)
FROM (
  SELECT * FROM (
    SELECT src.*,
           ROW_NUMBER() OVER (
             PARTITION BY esd
             ORDER BY
               (CASE WHEN soc IS NOT NULL AND TRIM(soc)<>'' THEN 1 ELSE 0 END
                + CASE WHEN pack_voltage IS NOT NULL AND TRIM(pack_voltage)<>'' THEN 1 ELSE 0 END
                + CASE WHEN charge_current IS NOT NULL AND TRIM(charge_current)<>'' THEN 1 ELSE 0 END
                + CASE WHEN max_temperature IS NOT NULL AND TRIM(max_temperature)<>'' THEN 1 ELSE 0 END) DESC,
               record_time DESC
           ) process_rank
    FROM ncs_sim_ods.ods_charging_process src
    WHERE esd IS NOT NULL AND TRIM(esd)<>'' AND esd<>'esd'
  ) ranked WHERE process_rank=1
) p
INNER JOIN ncs_sim_dwd.dwd_charging_order o ON p.esd = o.session_id
;

-- 3) 充电站元数据 DWD
CREATE TABLE IF NOT EXISTS dwd_charging_station_meta (
  station_id STRING,
  location_id STRING,
  facility_type INT,
  station_name STRING,
  address STRING,
  device_count INT,
  open_time STRING,
  update_time STRING
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE dwd_charging_station_meta
SELECT
  stationId,
  locationId,
  cast(facilityType AS INT),
  station_name,
  address,
  cast(device_count AS INT),
  open_time,
  update_time
FROM (
  SELECT * FROM (
    SELECT src.*,
           ROW_NUMBER() OVER (
             PARTITION BY stationId
             ORDER BY
               (CASE WHEN station_name IS NOT NULL AND TRIM(station_name)<>'' THEN 1 ELSE 0 END
                + CASE WHEN address IS NOT NULL AND TRIM(address)<>'' THEN 1 ELSE 0 END
                + CASE WHEN device_count IS NOT NULL AND TRIM(device_count)<>'' THEN 1 ELSE 0 END) DESC,
               update_time DESC
           ) station_rank
    FROM ncs_sim_ods.ods_charging_station_meta src
    WHERE stationId IS NOT NULL AND TRIM(stationId)<>'' AND stationId<>'stationId'
  ) ranked WHERE station_rank=1
) station_dedup;

-- 4) 教学验收宽明细：粒度为一次完整充电。
--    订单为主表，站点与BMS均LEFT JOIN；无BMS订单不会丢失。
CREATE TABLE IF NOT EXISTS dwd_charge_detail (
  session_id STRING,
  user_id STRING,
  station_id STRING,
  station_name STRING,
  address STRING,
  gun_type STRING,
  platform STRING,
  kwh DOUBLE,
  charge_fee DOUBLE,
  duration_hrs DOUBLE,
  start_time TIMESTAMP,
  charge_date STRING,
  start_hour INT,
  weekday STRING,
  is_weekend INT,
  soc DOUBLE,
  start_soc_level STRING,
  pack_voltage DOUBLE,
  charge_current DOUBLE,
  max_temperature DOUBLE,
  min_temperature DOUBLE,
  is_abnormal INT
) STORED AS ORC TBLPROPERTIES ('orc.compress'='SNAPPY');

INSERT OVERWRITE TABLE dwd_charge_detail
SELECT o.session_id,
       o.user_id,
       o.station_id,
       s.station_name,
       s.address,
       CASE o.facility_type WHEN 1 THEN '交流桩' WHEN 2 THEN '直流桩'
            WHEN 3 THEN '交直流一体桩' ELSE '其他类型' END,
       CASE LOWER(TRIM(o.platform)) WHEN 'ios' THEN 'iOS'
            WHEN 'android' THEN 'Android' WHEN 'web' THEN 'Web' ELSE TRIM(o.platform) END,
       o.kwh_total,
       o.charging_fees,
       o.charge_hours,
       o.created_ts,
       o.created_date,
       o.start_hour,
       o.weekday,
       CASE WHEN o.weekday IN ('Sat','Sun') THEN 1 ELSE 0 END,
       p.soc,
       CASE WHEN p.soc IS NULL THEN NULL WHEN p.soc < 20 THEN '<20%'
            WHEN p.soc < 50 THEN '20-49%' WHEN p.soc < 80 THEN '50-79%' ELSE '80%+' END,
       p.pack_voltage,
       p.charge_current,
       p.max_temperature,
       p.min_temperature,
       o.is_abnormal
FROM ncs_sim_dwd.dwd_charging_order o
LEFT JOIN ncs_sim_dwd.dwd_charging_station_meta s ON o.station_id = s.station_id
LEFT JOIN (
  SELECT esd, soc, pack_voltage, charge_current, max_temperature, min_temperature
  FROM (
    SELECT p.*,
           ROW_NUMBER() OVER (PARTITION BY esd ORDER BY record_time_ts DESC, soc DESC) AS process_rank
    FROM ncs_sim_dwd.dwd_charging_process p
  ) ranked_process
  WHERE process_rank = 1
) p ON o.session_id = p.esd;

-- 生产流水线不单独启动COUNT验证作业；最终输出校验会核对关键总量。
