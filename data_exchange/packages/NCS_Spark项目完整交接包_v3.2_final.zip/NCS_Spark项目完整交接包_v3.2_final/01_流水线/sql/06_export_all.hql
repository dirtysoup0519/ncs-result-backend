-- 备用目录导出：一次会话导出全部15个内部大屏指标。
SET hive.exec.mode.local.auto=false;
SET hive.exec.mode.local.auto.inputbytes.max=134217728;
SET hive.exec.mode.local.auto.input.files.max=20;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/kpi_total'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_ads.ads_kpi_total;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/revenue_trend'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_ads.ads_revenue_trend ORDER BY stat_date;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/revenue_monthly'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_ads.ads_revenue_monthly ORDER BY stat_month;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/station_top10'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_ads.ads_station_top10;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/platform_stat'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_ads.ads_platform_stat;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/hourly_stat'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_ads.ads_hourly_stat ORDER BY stat_hour;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/order_daily'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_dws.dws_order_daily ORDER BY stat_date;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/process_daily'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_dws.dws_process_daily ORDER BY stat_date;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/station_hour_heatmap'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_ads.ads_station_hour_heatmap ORDER BY station_id, stat_hour;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/duration_distribution'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_ads.ads_duration_distribution ORDER BY bucket_order;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/workday_weekend'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_ads.ads_workday_weekend ORDER BY day_type;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/workday_hour_compare'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_ads.ads_workday_hour_compare ORDER BY day_type, stat_hour;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/charge_type_stat'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_ads.ads_charge_type_stat ORDER BY facility_type;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/station_type_cross'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_ads.ads_station_type_cross ORDER BY station_id, facility_type;

INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/monthly_comparison'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT * FROM ncs_sim_ads.ads_monthly_comparison ORDER BY stat_month;

-- 机器学习连续序列的稀疏小时源；后续由Python补齐缺失小时。
INSERT OVERWRITE LOCAL DIRECTORY '${hivevar:export_root}/ml_hourly_sparse'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
SELECT
  from_unixtime(floor(unix_timestamp(created_ts) / 3600) * 3600, 'yyyy-MM-dd HH:00:00') AS ts,
  round(sum(kwh_total), 6) AS kwh
FROM ncs_sim_dwd.dwd_charging_order
WHERE created_ts IS NOT NULL AND kwh_total IS NOT NULL AND kwh_total >= 0
GROUP BY from_unixtime(floor(unix_timestamp(created_ts) / 3600) * 3600, 'yyyy-MM-dd HH:00:00')
ORDER BY ts;
