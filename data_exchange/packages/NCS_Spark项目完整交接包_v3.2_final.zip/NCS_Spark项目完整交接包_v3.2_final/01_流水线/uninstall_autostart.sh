#!/bin/bash
set -Eeuo pipefail

UNIT_NAME=ncs-spark-pipeline.service
sudo systemctl disable --now "$UNIT_NAME" || true
sudo rm -f "/etc/systemd/system/$UNIT_NAME"
sudo systemctl daemon-reload
echo "已移除NCS开机自启服务；数据、日志和流水线文件均未删除。"
