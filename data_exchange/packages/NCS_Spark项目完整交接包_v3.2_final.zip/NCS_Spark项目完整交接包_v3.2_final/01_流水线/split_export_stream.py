#!/usr/bin/env python3
import os
import sys

NAMES = {
    "kpi_total", "revenue_trend", "revenue_monthly", "station_top10",
    "platform_stat", "hourly_stat", "order_daily", "process_daily",
    "station_hour_heatmap", "duration_distribution", "workday_weekend",
    "workday_hour_compare", "charge_type_stat", "station_type_cross",
    "monthly_comparison",
}


def main():
    if len(sys.argv) != 3:
        print("用法: split_export_stream.py <SQL结果流> <发布暂存目录>", file=sys.stderr)
        return 2
    stream_path, output_dir = map(os.path.abspath, sys.argv[1:])
    os.makedirs(output_dir, exist_ok=True)
    handles = {}
    current = None
    seen = set()
    try:
        with open(stream_path, "r", encoding="utf-8", errors="replace") as source:
            for raw in source:
                line = raw.rstrip("\r\n")
                if line.startswith("__NCS_BEGIN__"):
                    name = line[len("__NCS_BEGIN__"):]
                    if name not in NAMES or current is not None:
                        raise ValueError("非法导出开始标记: {}".format(line))
                    current = name
                    seen.add(name)
                    handles[name] = open(os.path.join(output_dir, name + ".csv"), "w", encoding="utf-8", newline="")
                elif line.startswith("__NCS_END__"):
                    name = line[len("__NCS_END__"):]
                    if current != name:
                        raise ValueError("导出结束标记不匹配: {}".format(line))
                    handles[name].close()
                    current = None
                elif current is not None:
                    handles[current].write(line + "\n")
        if current is not None:
            raise ValueError("导出流未正常结束: {}".format(current))
        missing = NAMES - seen
        if missing:
            raise ValueError("缺少导出段: {}".format(",".join(sorted(missing))))
    finally:
        for handle in handles.values():
            if not handle.closed:
                handle.close()
    print("EXPORT_STREAM_OK files={}".format(len(seen)))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print("EXPORT_STREAM_FAILED: {}".format(exc), file=sys.stderr)
        sys.exit(1)
