#!/usr/bin/env python3
import calendar
import csv
import os
import shutil
import sys
from datetime import datetime, timedelta

from cleaning_rules import deduplicate_by_key, deduplicate_orders, prepare_valid_orders

ORDER_FIELDS = ["sessionId", "kwhTotal", "charging_fees", "created", "ended", "startTime", "endTime", "chargeTimeHrs", "weekday", "platform", "userId", "stationId", "locationId", "managerVehicle", "facilityType", "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat", "Sun"]
PROCESS_FIELDS = ["esd", "record_time", "soc", "pack_voltage (V)", "charge_current (A)", "max_cell_voltage (V)", "min_cell_voltage (V)", "max_temperature (℃)", "min_temperature (℃)", "available_energy (kw)", "available_capacity (Ah)"]
TIME_FORMAT = "%Y-%m-%d %H:%M:%S"


def read_dicts(path, fields):
    with open(path, "r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != fields:
            raise ValueError("表头不符合机器学习契约: {}".format(path))
        return list(reader)


def normalized_time(value):
    value = value.strip()
    if len(value) >= 5 and value[:2] == "00" and value[2:4].isdigit() and value[4] == "-":
        value = "2019" + value[4:]
    return datetime.strptime(value, TIME_FORMAT)


def write_retraining_files(input_dir, output_dir):
    raw_orders = read_dicts(os.path.join(input_dir, "nvv2t.csv"), ORDER_FIELDS)
    raw_processes = read_dicts(os.path.join(input_dir, "dsv13r2.csv"), PROCESS_FIELDS)
    orders, order_duplicates = deduplicate_orders(raw_orders)
    processes, process_duplicates = deduplicate_by_key(
        raw_processes, "esd", PROCESS_FIELDS[1:], latest_field="record_time")
    created_by_session = {row["sessionId"]: normalized_time(row["created"]) for row in orders}

    order_path = os.path.join(output_dir, "nvv2t_new.csv")
    with open(order_path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=ORDER_FIELDS)
        writer.writeheader()
        writer.writerows(orders)

    process_path = os.path.join(output_dir, "dsv13r2_new.csv")
    with open(process_path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=PROCESS_FIELDS)
        writer.writeheader()
        for row in processes:
            if row["esd"] not in created_by_session:
                raise ValueError("监测记录无法关联订单: {}".format(row["esd"]))
            fixed = dict(row)
            fixed["record_time"] = str(calendar.timegm(created_by_session[row["esd"]].timetuple()) * 1000)
            writer.writerow(fixed)
    return len(raw_orders), len(orders), len(raw_processes), len(processes), order_duplicates, process_duplicates


def write_history(orders, output_dir):
    hourly = {}
    for line, row in enumerate(orders, 2):
        started = normalized_time(row["created"])
        kwh = float(row["kwhTotal"])
        hours = float(row["chargeTimeHrs"])
        # 按充电持续时间均匀分摊到实际覆盖的小时。每笔订单分配后的总和仍等于kwhTotal。
        remaining_seconds = hours * 3600.0
        cursor = started
        avg_power_kw = kwh / hours
        while remaining_seconds > 1e-9:
            hour_start = cursor.replace(minute=0, second=0, microsecond=0)
            next_hour = hour_start + timedelta(hours=1)
            seconds = min(remaining_seconds, (next_hour - cursor).total_seconds())
            hourly[hour_start] = hourly.get(hour_start, 0.0) + avg_power_kw * seconds / 3600.0
            cursor += timedelta(seconds=seconds)
            remaining_seconds -= seconds
    if not hourly:
        raise ValueError("机器学习小时源为空")

    start, end = min(hourly), max(hourly)
    count = int((end - start).total_seconds() // 3600) + 1
    if count < 512:
        raise ValueError("连续小时不足512: {}".format(count))
    history_path = os.path.join(output_dir, "history.csv")
    with open(history_path, "w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["ts", "kwh"])
        for offset in range(count):
            ts = start + timedelta(hours=offset)
            writer.writerow([ts.strftime(TIME_FORMAT), "{:.6f}".format(hourly.get(ts, 0.0))])
    return count, sum(1 for offset in range(count) if start + timedelta(hours=offset) not in hourly)


def main():
    if len(sys.argv) != 3:
        print("用法: build_ml_outputs.py <输入目录> <ML输出目录>", file=sys.stderr)
        return 2
    input_dir, output_dir = map(os.path.abspath, sys.argv[1:])
    os.makedirs(output_dir, exist_ok=True)
    orders = read_dicts(os.path.join(input_dir, "nvv2t.csv"), ORDER_FIELDS)
    valid_orders, reason_counts, duplicate_count = prepare_valid_orders(orders)
    if not valid_orders:
        raise ValueError("清洗后没有可用于机器学习的有效订单")
    history_rows, filled_hours = write_history(valid_orders, output_dir)
    raw_order_rows, order_rows, raw_process_rows, process_rows, raw_order_duplicates, process_duplicates = write_retraining_files(input_dir, output_dir)
    # 兼容新上游交接包 07_export_train_data.sh 的标准文件名，
    # 同时保留组长模型已使用的 *_new.csv 名称。
    shutil.copyfile(os.path.join(output_dir, "nvv2t_new.csv"), os.path.join(output_dir, "nvv2t.csv"))
    shutil.copyfile(os.path.join(output_dir, "dsv13r2_new.csv"), os.path.join(output_dir, "dsv13r2.csv"))
    print("ML_OUTPUT_BUILT history={} filled_zero={} raw_orders={} valid_orders={} excluded_orders={} duplicates_removed={} process={} allocation=DURATION_PRORATED reasons={}".format(
        history_rows, filled_hours, raw_order_rows, len(valid_orders), raw_order_rows - len(valid_orders), duplicate_count,
        process_rows, dict(sorted(reason_counts.items()))))
    if raw_order_duplicates or process_duplicates:
        print("ML_DETAIL_DEDUP order_rows={} process_rows={} order_duplicates={} process_duplicates={}".format(
            order_rows, process_rows, raw_order_duplicates, process_duplicates))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print("ML_OUTPUT_FAILED: {}".format(exc), file=sys.stderr)
        sys.exit(1)
