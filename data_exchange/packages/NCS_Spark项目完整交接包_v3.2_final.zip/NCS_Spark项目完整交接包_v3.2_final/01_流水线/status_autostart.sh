#!/bin/bash
set -u

ROOT=$(cd "$(dirname "$0")" && pwd)
source "$ROOT/config.env"
echo "=== systemd ==="
systemctl status ncs-spark-pipeline.service --no-pager -l || true
echo "=== Hadoop/YARN ==="
timeout 15 jps || true
echo "=== latest autostart log ==="
tail -n 40 "$LOG_DIR/autostart.log" 2>/dev/null || true
echo "=== latest successful output ==="
if [ -f "$OUTPUT_DIR/manifest.json" ]; then
  echo "$OUTPUT_DIR/manifest.json"
else
  echo "尚无成功输出"
fi
