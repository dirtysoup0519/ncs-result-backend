#!/usr/bin/env python
from __future__ import print_function

import csv
import hashlib
import json
import os
import sys
from datetime import datetime, timedelta, timezone

from cleaning_rules import prepare_valid_orders

FIELDS = {
    "kpi_total.csv": 7,
    "revenue_trend.csv": 4,
    "revenue_monthly.csv": 4,
    "station_top10.csv": 6,
    "platform_stat.csv": 4,
    "hourly_stat.csv": 4,
    "order_daily.csv": 6,
    "process_daily.csv": 9,
    "station_hour_heatmap.csv": 6,
    "duration_distribution.csv": 4,
    "workday_weekend.csv": 6,
    "workday_hour_compare.csv": 6,
    "charge_type_stat.csv": 7,
    "station_type_cross.csv": 7,
    "monthly_comparison.csv": 11,
}

ORDER_FIELDS = ["sessionId", "kwhTotal", "charging_fees", "created", "ended", "startTime", "endTime", "chargeTimeHrs", "weekday", "platform", "userId", "stationId", "locationId", "managerVehicle", "facilityType", "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat", "Sun"]
PROCESS_FIELDS = ["esd", "record_time", "soc", "pack_voltage (V)", "charge_current (A)", "max_cell_voltage (V)", "min_cell_voltage (V)", "max_temperature (℃)", "min_temperature (℃)", "available_energy (kw)", "available_capacity (Ah)"]


def rows(path, count):
    with open(path, "r", encoding="utf-8", newline="") as handle:
        result = list(csv.reader(handle, delimiter="\t"))
    if not result:
        raise ValueError("空输出: {}".format(path))
    for line, row in enumerate(result, 1):
        if len(row) != count:
            raise ValueError("{}第{}行字段数为{}，预期{}".format(path, line, len(row), count))
    return result


def validate_ml(root):
    ml_dir = os.path.join(root, "ml")
    history_path = os.path.join(ml_dir, "history.csv")
    with open(history_path, "r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != ["ts", "kwh"]:
            raise ValueError("history.csv表头必须为ts,kwh")
        history = list(reader)
    if len(history) < 512:
        raise ValueError("history.csv不足512小时")
    previous = None
    for line, row in enumerate(history, 2):
        current = datetime.strptime(row["ts"], "%Y-%m-%d %H:%M:%S")
        value = float(row["kwh"])
        if value < 0:
            raise ValueError("history.csv第{}行kwh为负数".format(line))
        if previous is not None and current != previous + timedelta(hours=1):
            raise ValueError("history.csv第{}行不是连续小时".format(line))
        previous = current

    def checked_dict_rows(name, expected):
        with open(os.path.join(ml_dir, name), "r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if reader.fieldnames != expected:
                raise ValueError("{}表头不符合组长契约".format(name))
            result = list(reader)
        if not result:
            raise ValueError("{}为空".format(name))
        return result

    orders = checked_dict_rows("nvv2t_new.csv", ORDER_FIELDS)
    processes = checked_dict_rows("dsv13r2_new.csv", PROCESS_FIELDS)
    for line, row in enumerate(orders, 2):
        value = row["created"]
        normalized = "2019" + value[4:] if len(value) >= 5 and value[:2] == "00" and value[2:4].isdigit() and value[4] == "-" else value
        try:
            datetime.strptime(normalized, "%Y-%m-%d %H:%M:%S")
        except Exception:
            raise ValueError("nvv2t_new.csv第{}行created无法按上游2019规则解析".format(line))
    record_times = [row["record_time"] for row in processes]
    if any(not value.isdigit() or len(value) != 13 for value in record_times):
        raise ValueError("dsv13r2_new.csv存在不可用的毫秒时间戳")
    if len(set(record_times)) <= 1:
        raise ValueError("dsv13r2_new.csv的record_time仍为脱敏常量")
    for compatibility, canonical in (("nvv2t.csv", "nvv2t_new.csv"), ("dsv13r2.csv", "dsv13r2_new.csv")):
        with open(os.path.join(ml_dir, compatibility), "rb") as left, open(os.path.join(ml_dir, canonical), "rb") as right:
            if left.read() != right.read():
                raise ValueError("模型兼容文件与已验证文件不一致: {}".format(compatibility))
    valid_orders, rejection_counts, duplicate_count = prepare_valid_orders(orders)
    return {"history.csv": len(history), "nvv2t_new.csv": len(orders), "dsv13r2_new.csv": len(processes),
            "nvv2t.csv": len(orders), "dsv13r2.csv": len(processes)}


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_partner_contract(root, expected_orders):
    contract_dir = os.path.join(root, "contract_v2")
    path = os.path.join(contract_dir, "manifest.json")
    with open(path, "r", encoding="utf-8") as handle:
        manifest = json.load(handle)
    if manifest.get("status") != "SUCCESS" or manifest.get("schemaVersion") != "2.2.0":
        raise ValueError("contract_v2 manifest状态或版本无效")
    for key in ("timeRule", "displayTimeRule", "modelTimeRule"):
        if manifest.get(key) != "UPSTREAM_FIXED_YEAR_2019":
            raise ValueError("contract_v2时间规则未统一: {}={}".format(key, manifest.get(key)))
    datasets = manifest.get("datasets", [])
    required = {"dashboard_overview", "platform_distribution", "station_daily", "fee_energy_daily",
                "process_daily", "station_reference", "duration_distribution", "weekday_weekend_profile",
                "station_hour_daily", "load_hourly", "weekday_hour_profile", "charge_type_distribution",
                "station_charge_type", "station_top10_snapshot", "station_hour_heatmap_profile",
                "revenue_monthly", "kpi_period_comparison", "process_overview"}
    if {item.get("datasetCode") for item in datasets} != required:
        raise ValueError("contract_v2数据集清单不完整")
    for item in datasets:
        file_path = os.path.join(contract_dir, item["file"])
        if not os.path.isfile(file_path) or sha256(file_path) != item.get("checksum"):
            raise ValueError("contract_v2文件缺失或校验和错误: {}".format(item["file"]))
    overview = os.path.join(contract_dir, "dashboard_overview.csv")
    with open(overview, "r", encoding="utf-8-sig", newline="") as handle:
        record = next(csv.DictReader(handle))
    if int(record["total_order_count"]) != expected_orders:
        raise ValueError("contract_v2总订单数与旧版输出不一致")
    return {item["file"]: item["rowCount"] for item in datasets}


def main():
    if len(sys.argv) != 3:
        print("用法: validate_output.py <输出目录> <manifest路径>", file=sys.stderr)
        return 2
    root, manifest_path = sys.argv[1], sys.argv[2]
    loaded = {name: rows(os.path.join(root, name), count) for name, count in FIELDS.items()}
    kpi_orders = int(float(loaded["kpi_total.csv"][0][0]))
    daily_orders = sum(int(float(row[1])) for row in loaded["order_daily.csv"])
    monthly_orders = sum(int(float(row[1])) for row in loaded["revenue_monthly.csv"])
    platform_orders = sum(int(float(row[1])) for row in loaded["platform_stat.csv"])
    if len(loaded["kpi_total.csv"]) != 1:
        raise ValueError("kpi_total必须只有1行")
    if not (kpi_orders == daily_orders == monthly_orders == platform_orders):
        raise ValueError("订单总量不一致: KPI={} 日={} 月={} 平台={}".format(kpi_orders, daily_orders, monthly_orders, platform_orders))
    if any(not row[1] or not row[2] for row in loaded["station_top10.csv"]):
        raise ValueError("TOP10存在空站点名称或区域")
    if any(not row[1] for row in loaded["station_hour_heatmap.csv"]):
        raise ValueError("热力图存在空站点名称")
    duration_orders = sum(int(float(row[2])) for row in loaded["duration_distribution.csv"])
    workday_orders = sum(int(float(row[1])) for row in loaded["workday_weekend.csv"])
    workday_hour_orders = sum(int(float(row[2])) for row in loaded["workday_hour_compare.csv"])
    charge_type_orders = sum(int(float(row[2])) for row in loaded["charge_type_stat.csv"])
    station_type_orders = sum(int(float(row[4])) for row in loaded["station_type_cross.csv"])
    if any(not row[1] for row in loaded["station_type_cross.csv"]):
        raise ValueError("站点×桩型指标存在空站点名称")
    if not (duration_orders == workday_orders == workday_hour_orders == charge_type_orders == station_type_orders == kpi_orders):
        raise ValueError("扩展指标订单总量不一致: KPI={} 时长={} 工作日周末={} 工作日小时={} 桩型={} 站点桩型={}".format(
            kpi_orders, duration_orders, workday_orders, workday_hour_orders, charge_type_orders, station_type_orders))
    ml_files = validate_ml(root)
    with open(os.path.join(root, "ml", "nvv2t_new.csv"), "r", encoding="utf-8-sig", newline="") as handle:
        valid_ml_orders, unused_reasons, unused_duplicates = prepare_valid_orders(list(csv.DictReader(handle)))
    if len(valid_ml_orders) != kpi_orders:
        raise ValueError("DWD/ADS订单数与统一清洗规则不一致: 输出={} 有效原始订单={}".format(kpi_orders, len(valid_ml_orders)))
    partner_files = validate_partner_contract(root, kpi_orders)
    generated_at = datetime.now(timezone(timedelta(hours=8))).isoformat()
    manifest = {
        "status": "SUCCESS",
        "schemaVersion": "2.0.0",
        "generatedAt": generated_at,
        "loadMode": "FULL_SNAPSHOT",
        "timezone": "Asia/Shanghai",
        "total_orders": kpi_orders,
        "files": {name: {"rows": len(value), "fields": FIELDS[name],
                         "checksumAlgorithm": "SHA256", "checksum": sha256(os.path.join(root, name))}
                  for name, value in loaded.items()},
        "machine_learning": {"status": "SUCCESS", "files": ml_files},
        "partner_contract_v2": {"status": "SUCCESS", "manifest": "contract_v2/manifest.json", "files": partner_files},
    }
    with open(manifest_path, "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2, sort_keys=True)
    print("OUTPUT_OK total_orders={}".format(kpi_orders))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print("OUTPUT_INVALID: {}".format(exc), file=sys.stderr)
        sys.exit(1)
