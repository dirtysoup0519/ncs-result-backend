#!/bin/bash
set -Eeuo pipefail

ROOT=$(cd "$(dirname "$0")" && pwd)
source "$ROOT/config.env"

INPUT_DIR=${1:-$INBOUND_DIR}
ONE_CLICK_OUTPUT=${2:-$OUTPUT_DIR}

# The delivery package includes a validated simulation input. Prefer the
# normal inbound directory when it is complete; otherwise a no-argument run
# falls back to the bundled sample so the package can be tested immediately.
if [ "$#" -eq 0 ]; then
  inbound_complete=true
  for input_name in nvv2t.csv dsv13r2.csv nvv2t_md_end.csv; do
    [ -s "$INPUT_DIR/$input_name" ] || inbound_complete=false
  done
  if [ "$inbound_complete" != "true" ] && \
     [ -s "$ROOT/sample_input/nvv2t.csv" ] && \
     [ -s "$ROOT/sample_input/dsv13r2.csv" ] && \
     [ -s "$ROOT/sample_input/nvv2t_md_end.csv" ]; then
    INPUT_DIR="$ROOT/sample_input"
  fi
fi

BOOT_LOG="$LOG_DIR/one_click_bootstrap.log"
mkdir -p "$LOG_DIR" "$STATE_DIR" "$(dirname "$ONE_CLICK_OUTPUT")"
exec > >(tee -a "$BOOT_LOG") 2>&1

log() { echo "[$(date '+%F %T')] ONE_CLICK $*"; }

java_classes() {
  timeout 10 jps 2>/dev/null | awk 'NF >= 2 {print $2}' || true
}

has_java_class() {
  java_classes | grep -qx "$1"
}

port_ready() {
  # Do not use grep -q here. With `set -o pipefail`, grep may exit as soon as
  # it finds 9083 and make the producer receive SIGPIPE, falsely reporting
  # an already-listening Metastore as unavailable.
  /usr/sbin/ss -lnt 2>/dev/null | awk '{print $4}' | grep -E "(^|:)${HIVE_METASTORE_PORT}$" > /dev/null
}

show_processes() {
  log "当前Java服务（jps最多等待10秒）："
  timeout 10 jps 2>/dev/null || {
    log "jps暂时无响应，使用ps继续检查；这不会阻止自动启动。"
    ps -ef | grep -E 'NameNode|DataNode|ResourceManager|NodeManager' | grep -v grep || true
  }
}

start_hadoop() {
  local classes
  classes=$(java_classes)
  if ! grep -qx NameNode <<< "$classes" || ! grep -qx DataNode <<< "$classes" || ! grep -qx SecondaryNameNode <<< "$classes"; then
    log "HDFS未完整启动，正在运行 start-dfs.sh"
    "$HADOOP_HOME/sbin/start-dfs.sh"
  else
    log "HDFS已经运行，无需重复启动"
  fi

  classes=$(java_classes)
  if ! grep -qx ResourceManager <<< "$classes" || ! grep -qx NodeManager <<< "$classes"; then
    log "YARN未完整启动，正在运行 start-yarn.sh"
    "$HADOOP_HOME/sbin/start-yarn.sh"
  else
    log "YARN已经运行，无需重复启动"
  fi
}

start_metastore() {
  if port_ready; then
    log "Hive Metastore端口${HIVE_METASTORE_PORT}已经就绪"
  else
    log "正在启动 Hive Metastore（端口${HIVE_METASTORE_PORT}）"
    nohup "$HIVE_BIN" --service metastore > "$LOG_DIR/hive_metastore.log" 2>&1 < /dev/null &
  fi
}

wait_services() {
  local deadline=$((SECONDS + SERVICE_WAIT_SECONDS))
  while [ "$SECONDS" -lt "$deadline" ]; do
    local classes missing=""
    classes=$(java_classes)
    for daemon in $REQUIRED_DAEMONS; do
      grep -qx "$daemon" <<< "$classes" || missing="$missing $daemon"
    done
    if [ -z "$missing" ] && port_ready; then
      log "HDFS、YARN、Hive Metastore全部就绪"
      return 0
    fi
    log "等待服务启动；缺少:${missing:- 无}；Metastore=$(port_ready && echo 已就绪 || echo 未就绪)"
    sleep 5
  done
  log "服务启动超时。请查看 $BOOT_LOG 和 $LOG_DIR/hive_metastore.log"
  return 1
}

check_input() {
  local missing=0
  for name in nvv2t.csv dsv13r2.csv nvv2t_md_end.csv; do
    if [ ! -s "$INPUT_DIR/$name" ]; then
      log "缺少输入文件：$INPUT_DIR/$name"
      missing=1
    fi
  done
  [ "$missing" -eq 0 ] || return 1
  log "输入文件检查通过：$INPUT_DIR"
}

log "开始一键运行"
log "流水线目录：$ROOT"
log "输入目录：$INPUT_DIR"
log "输出目录：$ONE_CLICK_OUTPUT"
show_processes
start_hadoop
start_metastore
wait_services
show_processes
check_input

log "开始运行 Spark SQL 数据清洗与分析"
SQL_ENGINE=spark OUTPUT_DIR="$ONE_CLICK_OUTPUT" bash "$ROOT/run_pipeline.sh" "$INPUT_DIR"
log "全部完成。结果目录：$ONE_CLICK_OUTPUT"
log "结果清单：$ONE_CLICK_OUTPUT/manifest.json"
