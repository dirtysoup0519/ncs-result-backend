#!/usr/bin/env python3
"""订单清洗规则的唯一 Python 口径。

ODS/原始交接文件保留所有记录；DWD、ADS、机器学习小时序列和伙伴指标
只使用通过本模块校验的业务有效订单。
"""
from collections import Counter
from datetime import datetime


MAX_CHARGE_HOURS = 24.0
MAX_AVG_POWER_KW = 120.0
TIME_FORMAT = "%Y-%m-%d %H:%M:%S"


def normalized_time(value):
    value = (value or "").strip()
    if len(value) >= 5 and value[:2] == "00" and value[2:4].isdigit() and value[4] == "-":
        value = "2019" + value[4:]
    return datetime.strptime(value, TIME_FORMAT)


def order_rejection_reasons(row):
    reasons = []
    try:
        kwh = float(row.get("kwhTotal") or 0)
        hours = float(row.get("chargeTimeHrs") or 0)
    except (TypeError, ValueError):
        return ["INVALID_NUMERIC"]

    if kwh <= 0:
        reasons.append("NON_POSITIVE_KWH")
    if hours <= 0:
        reasons.append("NON_POSITIVE_DURATION")
    if hours > MAX_CHARGE_HOURS:
        reasons.append("DURATION_OVER_24H")
    if hours > 0 and kwh / hours > MAX_AVG_POWER_KW:
        reasons.append("AVG_POWER_OVER_120KW")
    try:
        if normalized_time(row.get("ended")) < normalized_time(row.get("created")):
            reasons.append("ENDED_BEFORE_CREATED")
    except (TypeError, ValueError):
        reasons.append("INVALID_TIME")
    return reasons


def filter_valid_orders(orders):
    valid = []
    reason_counts = Counter()
    for row in orders:
        reasons = order_rejection_reasons(row)
        if reasons:
            reason_counts.update(reasons)
        else:
            valid.append(row)
    return valid, reason_counts


def _order_quality_key(row):
    """同一sessionId冲突时，优先保留信息完整、结束时间较新的有效记录。"""
    important = ("userId", "stationId", "locationId", "platform", "weekday", "created", "ended")
    completeness = sum(bool((row.get(name) or "").strip()) for name in important)
    try:
        ended = normalized_time(row.get("ended"))
    except (TypeError, ValueError):
        ended = datetime.min
    try:
        created = normalized_time(row.get("created"))
    except (TypeError, ValueError):
        created = datetime.min
    try:
        kwh = float(row.get("kwhTotal") or 0)
    except (TypeError, ValueError):
        kwh = 0.0
    return completeness, ended, created, kwh, tuple(sorted(row.items()))


def deduplicate_orders(orders):
    """按sessionId确定性择优去重，返回去重结果和被移除行数。"""
    selected = {}
    for row in orders:
        key = (row.get("sessionId") or "").strip()
        if key not in selected or _order_quality_key(row) > _order_quality_key(selected[key]):
            selected[key] = row
    return list(selected.values()), len(orders) - len(selected)


def prepare_valid_orders(orders):
    """先剔除业务异常，再按主键去重。"""
    valid, reason_counts = filter_valid_orders(orders)
    deduplicated, duplicate_count = deduplicate_orders(valid)
    return deduplicated, reason_counts, duplicate_count


def deduplicate_by_key(rows, key, completeness_fields, latest_field=None):
    """通用主键择优去重：完整字段更多者优先，其次按时间/版本字段较大者。"""
    selected = {}
    for row in rows:
        value = (row.get(key) or "").strip()
        completeness = sum(bool((row.get(name) or "").strip()) for name in completeness_fields)
        latest = (row.get(latest_field) or "").strip() if latest_field else ""
        rank = (completeness, latest, tuple(sorted(row.items())))
        if value not in selected or rank > selected[value][0]:
            selected[value] = (rank, row)
    return [item[1] for item in selected.values()], len(rows) - len(selected)
