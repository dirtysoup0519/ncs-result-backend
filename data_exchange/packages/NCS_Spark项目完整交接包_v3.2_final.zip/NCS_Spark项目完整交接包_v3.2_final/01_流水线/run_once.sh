#!/bin/bash
set -Eeuo pipefail

ROOT=$(cd "$(dirname "$0")" && pwd)
exec bash "$ROOT/一键启动流水线.sh" "$@"
