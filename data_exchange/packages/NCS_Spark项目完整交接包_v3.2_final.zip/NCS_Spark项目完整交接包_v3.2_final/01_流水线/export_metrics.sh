#!/bin/bash
set -euo pipefail

OUT=${1:?用法: export_metrics.sh <临时输出目录>}
MODE=${2:-run-hive}
HIVE_BIN=${HIVE_BIN:-hive}
mkdir -p "$OUT"

EXPORT_ROOT="$OUT/.hive_export"
if [ "$MODE" != "--collect-only" ]; then
  rm -rf "$EXPORT_ROOT"
  mkdir -p "$EXPORT_ROOT"
  "$HIVE_BIN" --silent --hiveconf hive.cli.print.header=false \
    --hivevar export_root="$EXPORT_ROOT" \
    -f "$(cd "$(dirname "$0")" && pwd)/sql/06_export_all.hql"
fi

for name in \
  kpi_total revenue_trend revenue_monthly station_top10 platform_stat hourly_stat \
  order_daily process_daily station_hour_heatmap duration_distribution \
  workday_weekend monthly_comparison; do
  src="$EXPORT_ROOT/$name"
  if [ ! -d "$src" ]; then
    echo "Hive未生成导出目录: $src" >&2
    exit 1
  fi
  find "$src" -maxdepth 1 -type f ! -name '.*' -exec cat {} + > "$OUT/$name.csv"
done

src="$EXPORT_ROOT/ml_hourly_sparse"
if [ ! -d "$src" ]; then
  echo "Hive未生成机器学习小时源目录: $src" >&2
  exit 1
fi
find "$src" -maxdepth 1 -type f ! -name '.*' -exec cat {} + > "$OUT/.ml_hourly_sparse.tsv"

rm -rf "$EXPORT_ROOT"
