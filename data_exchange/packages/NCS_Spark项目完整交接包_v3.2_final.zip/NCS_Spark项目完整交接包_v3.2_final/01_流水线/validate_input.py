#!/usr/bin/env python
from __future__ import print_function

import csv
import os
import sys

EXPECTED = {
    "nvv2t.csv": ["sessionId", "kwhTotal", "charging_fees", "created", "ended", "startTime", "endTime", "chargeTimeHrs", "weekday", "platform", "userId", "stationId", "locationId", "managerVehicle", "facilityType", "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat", "Sun"],
    "dsv13r2.csv": ["esd", "record_time", "soc", "pack_voltage (V)", "charge_current (A)", "max_cell_voltage (V)", "min_cell_voltage (V)", "max_temperature (℃)", "min_temperature (℃)", "available_energy (kw)", "available_capacity (Ah)"],
    "nvv2t_md_end.csv": ["stationId", "locationId", "facilityType", "station_name", "address", "device_count", "open_time", "update_time"],
}


def load(path, expected):
    with open(path, "r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != expected:
            raise ValueError("表头不符合契约: {}".format(path))
        rows = list(reader)
    if not rows:
        raise ValueError("文件没有数据: {}".format(path))
    if any(list(row.values()) == expected for row in rows):
        raise ValueError("数据区包含重复表头: {}".format(path))
    return rows


def unique(rows, key, label, allow_duplicates=False):
    values = [row[key] for row in rows]
    if any(not value for value in values):
        raise ValueError("{}存在空值".format(label))
    if len(values) != len(set(values)):
        duplicate_count = len(values) - len(set(values))
        if not allow_duplicates:
            raise ValueError("{}不唯一".format(label))
        print("INPUT_WARN {}重复{}行；ODS保留，DWD按完整度和最新结束时间择优保留一条".format(label, duplicate_count))
    return set(values)


def numeric(rows, keys, label):
    for line, row in enumerate(rows, 2):
        for key in keys:
            try:
                float(row[key])
            except Exception:
                raise ValueError("{}第{}行字段{}不是数值".format(label, line, key))


def main():
    if len(sys.argv) != 2:
        print("用法: validate_input.py <输入目录>", file=sys.stderr)
        return 2
    root = os.path.abspath(sys.argv[1])
    data = {}
    for name, header in EXPECTED.items():
        path = os.path.join(root, name)
        if not os.path.isfile(path):
            raise ValueError("缺少输入文件: {}".format(path))
        data[name] = load(path, header)

    orders = data["nvv2t.csv"]
    process = data["dsv13r2.csv"]
    stations = data["nvv2t_md_end.csv"]
    sessions = unique(orders, "sessionId", "订单sessionId", allow_duplicates=True)
    station_ids = unique(stations, "stationId", "站点stationId", allow_duplicates=True)
    unique(process, "esd", "监测esd", allow_duplicates=True)
    numeric(orders, ["kwhTotal", "charging_fees", "startTime", "endTime", "chargeTimeHrs", "managerVehicle", "facilityType"], "订单")
    numeric(process, ["soc", "pack_voltage (V)", "charge_current (A)", "max_cell_voltage (V)", "min_cell_voltage (V)", "max_temperature (℃)", "min_temperature (℃)", "available_energy (kw)", "available_capacity (Ah)"], "监测")
    numeric(stations, ["facilityType", "device_count"], "站点")

    missing_process = sorted({row["esd"] for row in process} - sessions)
    missing_stations = sorted({row["stationId"] for row in orders} - station_ids)
    if missing_process:
        raise ValueError("监测记录存在{}个未匹配订单".format(len(missing_process)))
    if missing_stations:
        raise ValueError("订单存在{}个未匹配站点".format(len(missing_stations)))

    print("INPUT_OK orders={} process={} stations={} users={} used_stations={}".format(
        len(orders), len(process), len(stations), len({r["userId"] for r in orders}), len({r["stationId"] for r in orders})
    ))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print("INPUT_INVALID: {}".format(exc), file=sys.stderr)
        sys.exit(1)
