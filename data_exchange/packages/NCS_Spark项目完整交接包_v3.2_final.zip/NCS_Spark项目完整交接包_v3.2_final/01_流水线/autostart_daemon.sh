#!/bin/bash
set -uo pipefail

ROOT=$(cd "$(dirname "$0")" && pwd)
source "$ROOT/config.env"
AUTOSTART_LOG="$LOG_DIR/autostart.log"
READY_MARKER="$STATE_DIR/autostart_ready"
mkdir -p "$STATE_DIR" "$LOG_DIR"
exec >> "$AUTOSTART_LOG" 2>&1

log() { echo "[$(date '+%F %T')] AUTOSTART $*"; }

java_classes() {
  timeout 15 jps 2>/dev/null | awk '{print $2}' || true
}

port_ready() {
  /usr/sbin/ss -lnt 2>/dev/null | awk '{print $4}' | grep -E "(^|:)${HIVE_METASTORE_PORT}$" > /dev/null
}

start_hadoop_if_needed() {
  [ "$AUTO_START_HADOOP" = "true" ] || return 0
  local classes
  classes=$(java_classes)
  if ! grep -qx NameNode <<< "$classes" || ! grep -qx DataNode <<< "$classes" || ! grep -qx SecondaryNameNode <<< "$classes"; then
    log "starting HDFS"
    "$HADOOP_HOME/sbin/start-dfs.sh" || log "start-dfs.sh returned non-zero; readiness check will decide"
  fi
  classes=$(java_classes)
  if ! grep -qx ResourceManager <<< "$classes" || ! grep -qx NodeManager <<< "$classes"; then
    log "starting YARN"
    "$HADOOP_HOME/sbin/start-yarn.sh" || log "start-yarn.sh returned non-zero; readiness check will decide"
  fi
}

start_metastore_if_needed() {
  [ "$AUTO_START_METASTORE" = "true" ] || return 0
  if ! port_ready; then
    log "starting Hive Metastore on port $HIVE_METASTORE_PORT"
    nohup "$HIVE_BIN" --service metastore > "$LOG_DIR/hive_metastore.log" 2>&1 < /dev/null &
  fi
}

wait_until_ready() {
  local deadline=$((SECONDS + SERVICE_WAIT_SECONDS))
  while [ "$SECONDS" -lt "$deadline" ]; do
    local classes missing=""
    classes=$(java_classes)
    for daemon in $REQUIRED_DAEMONS; do
      grep -qx "$daemon" <<< "$classes" || missing="$missing $daemon"
    done
    if [ -z "$missing" ] && { [ "$AUTO_START_METASTORE" != "true" ] || port_ready; }; then
      log "services ready: $REQUIRED_DAEMONS; metastore_port=$HIVE_METASTORE_PORT"
      return 0
    fi
    log "waiting for services; missing:${missing:- none}; metastore_ready=$(port_ready && echo yes || echo no)"
    sleep 5
  done
  log "service readiness timed out after ${SERVICE_WAIT_SECONDS}s"
  return 1
}

rm -f "$READY_MARKER"
log "daemon starting root=$ROOT"
start_hadoop_if_needed
start_metastore_if_needed
wait_until_ready || exit 1
touch "$READY_MARKER"

while true; do
  if bash "$ROOT/run_if_changed.sh"; then
    touch "$READY_MARKER"
  else
    log "pipeline attempt failed; keeping previous published output and retrying later"
  fi
  sleep "$AUTOSTART_POLL_SECONDS"
done
