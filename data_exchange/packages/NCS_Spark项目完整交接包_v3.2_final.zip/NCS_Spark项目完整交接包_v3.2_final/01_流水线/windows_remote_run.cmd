@echo off
setlocal EnableExtensions EnableDelayedExpansion
title NCS Spark v3.2 Remote Runner
cd /d "%~dp0"

set "CONFIG_FILE=%~dp0remote_host.txt"
set "SSH_USER=hadoop"
set "REMOTE_DIR=/home/hadoop/ncs_spark_pipeline_v32"

if exist "%CONFIG_FILE%" (
  for /f "usebackq delims=" %%A in ("%CONFIG_FILE%") do if not defined VM_HOST set "VM_HOST=%%A"
)

if not defined VM_HOST (
  echo First run: enter the VM IPv4 address, for example 192.168.10.100
  set /p "VM_HOST=VM IP: "
  if not defined VM_HOST goto config_error
  >"%CONFIG_FILE%" echo !VM_HOST!
)

where ssh >nul 2>&1
if errorlevel 1 goto no_ssh

echo.
echo ============================================================
echo Connecting to %SSH_USER%@%VM_HOST%
echo Remote directory: %REMOTE_DIR%
echo Enter the Linux password for hadoop when prompted.
echo ============================================================
echo.

ssh -tt "%SSH_USER%@%VM_HOST%" "cd '%REMOTE_DIR%' && chmod +x *.sh && bash run_once.sh"
set "RESULT=%ERRORLEVEL%"

echo.
if "%RESULT%"=="0" (
  echo [SUCCESS] Remote pipeline completed.
  echo Output: /home/hadoop/dashboard/sim_data
) else (
  echo [FAILED] Remote execution exit code: %RESULT%
  echo Check that the VM is running, the IP is correct, and the remote directory exists.
  echo If the IP changed, delete remote_host.txt and run this file again.
)
echo.
pause
exit /b %RESULT%

:no_ssh
echo [FAILED] Windows OpenSSH client was not found.
echo Install "OpenSSH Client" in Windows Optional Features.
pause
exit /b 2

:config_error
echo [FAILED] VM IP was not entered.
pause
exit /b 3
