# Windows 双击远程运行说明

## 准备工作

1. 虚拟机必须已经开机并能从Windows访问；
2. 流水线文件夹已经上传至 `/home/hadoop/ncs_spark_pipeline_v32`；
3. Windows已安装OpenSSH客户端。Windows 10/11通常自带，可在PowerShell输入 `ssh -V` 检查。

## 使用方法

为避免不同Windows区域设置造成中文批处理乱码，请双击纯英文入口：

```text
windows_remote_run.cmd
```

第一次运行会要求输入虚拟机IP。IP会保存在同目录的 `remote_host.txt`，以后不再询问。随后如提示 `password`，输入虚拟机中 `hadoop` 用户的密码。

脚本会在远程虚拟机执行：

```bash
cd /home/hadoop/ncs_spark_pipeline_v32
chmod +x *.sh
bash run_once.sh
```

`run_once.sh` 会自动检查和启动HDFS、YARN、Hive Metastore，然后运行Spark SQL流水线。Windows窗口会一直显示远程日志，完成或失败后都会暂停，不会自动闪退。

## IP变化怎么办

删除Windows流水线文件夹中的：

```text
remote_host.txt
```

再次双击CMD，重新输入IP。

## 修改远程目录

默认目录是 `/home/hadoop/ncs_spark_pipeline_v32`。如果上传到了其他位置，用记事本打开 `windows_remote_run.cmd`，修改：

```text
set "REMOTE_DIR=/home/hadoop/ncs_spark_pipeline_v32"
```

## 常见错误

- `Could not resolve hostname`：填写了主机名而Windows无法解析，请使用虚拟机IPv4地址；
- `Connection timed out`：虚拟机未开机、网络模式不通或IP错误；
- `Connection refused`：虚拟机SSH服务未启动；
- `No such file or directory`：远程目录填错，或ZIP解压后多套了一层文件夹；
- `Permission denied`：hadoop用户密码错误或SSH登录被拒绝。
