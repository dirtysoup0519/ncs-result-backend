#!/bin/bash
set -Eeuo pipefail

ROOT=$(cd "$(dirname "$0")" && pwd)
source "$ROOT/config.env"
mkdir -p "$STATE_DIR"

for name in dsv13r2.csv nvv2t.csv nvv2t_md_end.csv; do
  [ -f "$INBOUND_DIR/$name" ] || exit 0
done

NEW_HASH=$(sha256sum "$INBOUND_DIR/dsv13r2.csv" "$INBOUND_DIR/nvv2t.csv" "$INBOUND_DIR/nvv2t_md_end.csv" | sha256sum | awk '{print $1}')
OLD_HASH=$(cat "$STATE_DIR/last_input.sha256" 2>/dev/null || true)
if [ "$NEW_HASH" = "$OLD_HASH" ] && \
   [ -f "$STATE_DIR/last_success.json" ] && \
   [ -f "$OUTPUT_DIR/manifest.json" ]; then
  exit 0
fi

bash "$ROOT/run_pipeline.sh" "$INBOUND_DIR"
printf '%s\n' "$NEW_HASH" > "$STATE_DIR/last_input.sha256"
