#!/usr/bin/env python3
"""生成下游 MySQL/API 可直接导入的 v2 数据合同。

旧版 12 个无表头 TSV 保持不变；本脚本只在 contract_v2/
额外生成带表头 CSV 和独立 manifest，因此不会破坏已有 MySQL/前端。
"""
from __future__ import print_function

import calendar
import csv
import hashlib
import json
import os
import sys
from collections import defaultdict
from datetime import datetime, timedelta, timezone

from cleaning_rules import MAX_AVG_POWER_KW, MAX_CHARGE_HOURS, deduplicate_by_key, prepare_valid_orders


ORDER_FIELDS = ["sessionId", "kwhTotal", "charging_fees", "created", "ended", "startTime", "endTime", "chargeTimeHrs", "weekday", "platform", "userId", "stationId", "locationId", "managerVehicle", "facilityType", "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat", "Sun"]
PROCESS_FIELDS = ["esd", "record_time", "soc", "pack_voltage (V)", "charge_current (A)", "max_cell_voltage (V)", "min_cell_voltage (V)", "max_temperature (℃)", "min_temperature (℃)", "available_energy (kw)", "available_capacity (Ah)"]
STATION_FIELDS = ["stationId", "locationId", "facilityType", "station_name", "address", "device_count", "open_time", "update_time"]
SCHEMA_VERSION = "2.2.0"
METRIC_VERSION = "2.2.0"


def read_csv(path, expected):
    with open(path, "r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != expected:
            raise ValueError("表头不符合契约: {}".format(path))
        return list(reader)


def raw_time(value):
    value = value.strip()
    normalized = "2019" + value[4:] if len(value) >= 5 and value[:2] == "00" and value[2:4].isdigit() and value[4] == "-" else value
    return datetime.strptime(normalized, "%Y-%m-%d %H:%M:%S")


def contract_time(value):
    """统一合同口径：脱敏年份0014/0015按上游交接规则映射为2019。"""
    return raw_time(value)


def f(value):
    return float(value or 0)


def write_dataset(root, name, fields, rows, primary_key, source_tables, granularity):
    path = os.path.join(root, name + ".csv")
    with open(path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return {
        "datasetCode": name,
        "file": name + ".csv",
        "fields": fields,
        "primaryKey": primary_key,
        "granularity": granularity,
        "rowCount": len(rows),
        "checksumAlgorithm": "SHA256",
        "checksum": digest.hexdigest(),
        "sourceTables": source_tables,
    }


def rounded(value):
    return round(value + 0.0, 2)


def charge_type_name(value):
    return {"1": "AC", "2": "DC", "3": "AC_DC"}.get(str(value), "OTHER")


def allocate_order_hours(row):
    """将订单电量和费用按充电持续时间分摊到实际覆盖的自然小时。"""
    started = contract_time(row["created"])
    hours = f(row["chargeTimeHrs"])
    power = f(row["kwhTotal"]) / hours
    fee_rate = f(row["charging_fees"]) / hours
    remaining = hours * 3600.0
    cursor = started
    while remaining > 1e-9:
        hour = cursor.replace(minute=0, second=0, microsecond=0)
        next_hour = hour + timedelta(hours=1)
        seconds = min(remaining, (next_hour - cursor).total_seconds())
        fraction_hours = seconds / 3600.0
        yield hour, power * fraction_hours, fee_rate * fraction_hours
        cursor += timedelta(seconds=seconds)
        remaining -= seconds


def main():
    if len(sys.argv) != 5:
        print("用法: build_partner_outputs.py <输入目录> <旧版输出目录> <contract_v2目录> <run_id>", file=sys.stderr)
        return 2
    input_dir, legacy_dir, out_dir, run_id = sys.argv[1:]
    input_dir, legacy_dir, out_dir = map(os.path.abspath, (input_dir, legacy_dir, out_dir))
    os.makedirs(out_dir, exist_ok=True)

    raw_orders = read_csv(os.path.join(input_dir, "nvv2t.csv"), ORDER_FIELDS)
    raw_processes = read_csv(os.path.join(input_dir, "dsv13r2.csv"), PROCESS_FIELDS)
    raw_stations = read_csv(os.path.join(input_dir, "nvv2t_md_end.csv"), STATION_FIELDS)
    stations, station_duplicate_count = deduplicate_by_key(
        raw_stations, "stationId", STATION_FIELDS[1:], latest_field="update_time")
    station_by_id = {row["stationId"]: row for row in stations}
    raw_order_by_session = {row["sessionId"]: row for row in raw_orders}

    missing_station = sorted({row["stationId"] for row in raw_orders if row["stationId"] not in station_by_id})
    missing_process_order = sorted({row["esd"] for row in raw_processes if row["esd"] not in raw_order_by_session})
    if missing_station or missing_process_order:
        raise ValueError("交接关联失败: station={} process={}".format(len(missing_station), len(missing_process_order)))

    orders, rejection_counts, duplicate_count = prepare_valid_orders(raw_orders)
    if not orders:
        raise ValueError("清洗后没有业务有效订单")
    valid_sessions = {row["sessionId"] for row in orders}
    valid_processes = [row for row in raw_processes if row["esd"] in valid_sessions]
    processes, process_duplicate_count = deduplicate_by_key(
        valid_processes, "esd", PROCESS_FIELDS[1:], latest_field="record_time")
    order_by_session = {row["sessionId"]: row for row in orders}

    display_dates = [contract_time(row["created"]) for row in orders]
    start_date = min(display_dates).strftime("%Y-%m-%d")
    end_date = max(display_dates).strftime("%Y-%m-%d")
    total_orders = len(orders)
    total_kwh = sum(f(row["kwhTotal"]) for row in orders)
    total_fees = sum(f(row["charging_fees"]) for row in orders)
    active_stations = len({row["stationId"] for row in orders})

    legacy_kpi = os.path.join(legacy_dir, "kpi_total.csv")
    with open(legacy_kpi, "r", encoding="utf-8", newline="") as handle:
        first = next(csv.reader(handle, delimiter="\t"))
    if int(float(first[0])) != total_orders:
        raise ValueError("新旧合同总订单数不一致: legacy={} v2={}".format(first[0], total_orders))

    manifests = []
    manifests.append(write_dataset(
        out_dir, "dashboard_overview",
        ["start_date", "end_date", "total_order_count", "total_fees", "total_kwh", "total_user_count", "active_station_count", "station_count", "metric_version"],
        [{"start_date": start_date, "end_date": end_date, "total_order_count": total_orders,
          "total_fees": rounded(total_fees), "total_kwh": rounded(total_kwh),
          "total_user_count": len({row["userId"] for row in orders}),
          "active_station_count": active_stations, "station_count": len(stations),
          "metric_version": METRIC_VERSION}],
        ["start_date", "end_date"], ["ncs_sim_dwd.dwd_charging_order", "ncs_sim_dwd.dwd_charging_station_meta"], ["full_period"]
    ))

    platform = defaultdict(lambda: [0, 0.0])
    for row in orders:
        platform[row["platform"]][0] += 1
        platform[row["platform"]][1] += f(row["charging_fees"])
    platform_rows = []
    for code in sorted(platform):
        count, fees = platform[code]
        platform_rows.append({"start_date": start_date, "end_date": end_date, "platform_code": code,
                              "order_count": count, "order_ratio": rounded(count * 100.0 / total_orders),
                              "total_fees": rounded(fees),
                              "fee_ratio": rounded(fees * 100.0 / total_fees) if total_fees else 0.0})
    manifests.append(write_dataset(out_dir, "platform_distribution",
        ["start_date", "end_date", "platform_code", "order_count", "order_ratio", "total_fees", "fee_ratio"],
        platform_rows, ["start_date", "end_date", "platform_code"], ["ncs_sim_dwd.dwd_charging_order"], ["period", "platform"] ))

    daily = defaultdict(lambda: [0, 0.0, 0.0, 0.0, set()])
    station_daily = defaultdict(lambda: [0, 0.0, 0.0])
    station_hour_daily = defaultdict(lambda: [0, 0.0, 0.0])
    station_period = defaultdict(lambda: [0, 0.0, 0.0])
    station_hour_period = defaultdict(lambda: [0, 0.0, 0.0])
    monthly = defaultdict(lambda: [0, 0.0, 0.0, set(), set()])
    duration = {1: ["0-1h", 0], 2: ["1-2h", 0], 3: ["2-3h", 0], 4: ["3h+", 0]}
    day_type = defaultdict(lambda: [0, 0.0, 0.0, 0.0, set()])
    day_type_hour = defaultdict(lambda: [0, 0.0, 0.0, 0.0])
    charge_type = defaultdict(lambda: [0, 0.0, 0.0, 0.0])
    station_charge_type = defaultdict(lambda: [0, 0.0, 0.0])
    logical_hour = defaultdict(lambda: [0, 0.0])
    for row in orders:
        dt_display = contract_time(row["created"])
        date = dt_display.strftime("%Y-%m-%d")
        kwh, fees, hours = f(row["kwhTotal"]), f(row["charging_fees"]), f(row["chargeTimeHrs"])
        d = daily[date]
        d[0] += 1; d[1] += kwh; d[2] += fees; d[3] += hours; d[4].add(row["userId"])
        sd = station_daily[(date, row["stationId"])]
        sd[0] += 1; sd[1] += kwh; sd[2] += fees
        sp = station_period[row["stationId"]]
        sp[0] += 1; sp[1] += kwh; sp[2] += fees
        month_value = monthly[dt_display.strftime("%Y-%m")]
        month_value[0] += 1; month_value[1] += kwh; month_value[2] += fees
        month_value[3].add(row["userId"]); month_value[4].add(row["stationId"])
        bucket = 1 if hours < 1 else 2 if hours < 2 else 3 if hours < 3 else 4
        duration[bucket][1] += 1
        kind = "weekend" if row["weekday"] in ("Sat", "Sun") else "workday"
        wd = day_type[kind]
        wd[0] += 1; wd[1] += kwh; wd[2] += fees; wd[3] += hours; wd[4].add(row["userId"])
        wdh = day_type_hour[(kind, dt_display.hour)]
        wdh[0] += 1; wdh[1] += kwh; wdh[2] += fees; wdh[3] += hours
        type_code = row["facilityType"]
        ct = charge_type[type_code]
        ct[0] += 1; ct[1] += kwh; ct[2] += fees; ct[3] += hours
        sct = station_charge_type[(row["stationId"], type_code)]
        sct[0] += 1; sct[1] += kwh; sct[2] += fees
        for model_hour, allocated_kwh, allocated_fees in allocate_order_hours(row):
            sh = station_hour_daily[(model_hour.strftime("%Y-%m-%d"), row["stationId"], model_hour.hour)]
            sh[0] += 1; sh[1] += allocated_kwh; sh[2] += allocated_fees
            shp = station_hour_period[(row["stationId"], model_hour.hour)]
            shp[0] += 1; shp[1] += allocated_kwh; shp[2] += allocated_fees
            logical_hour[model_hour][0] += 1; logical_hour[model_hour][1] += allocated_kwh

    daily_rows = [{"data_date": k, "order_count": v[0], "total_kwh": rounded(v[1]),
                   "total_fees": rounded(v[2]), "total_charge_hours": rounded(v[3]), "user_count": len(v[4])}
                  for k, v in sorted(daily.items())]
    manifests.append(write_dataset(out_dir, "fee_energy_daily",
        ["data_date", "order_count", "total_kwh", "total_fees", "total_charge_hours", "user_count"],
        daily_rows, ["data_date"], ["ncs_sim_dws.dws_order_daily"], ["date"] ))

    station_daily_rows = []
    for (date, station_id), value in sorted(station_daily.items()):
        meta = station_by_id[station_id]
        station_daily_rows.append({"data_date": date, "station_id": station_id,
            "station_name": meta["station_name"], "location_id": meta["locationId"],
            "order_count": value[0], "total_kwh": rounded(value[1]), "total_fees": rounded(value[2])})
    manifests.append(write_dataset(out_dir, "station_daily",
        ["data_date", "station_id", "station_name", "location_id", "order_count", "total_kwh", "total_fees"],
        station_daily_rows, ["data_date", "station_id"], ["ncs_sim_dws.dws_order_station_daily", "ncs_sim_dwd.dwd_charging_station_meta"], ["date", "station"] ))

    ranked_stations = sorted(station_period.items(), key=lambda item: (-item[1][1], item[0]))
    station_top10_rows = []
    for rank, (station_id, value) in enumerate(ranked_stations[:10], 1):
        meta = station_by_id[station_id]
        station_top10_rows.append({"start_date": start_date, "end_date": end_date,
            "rank_order": rank, "station_id": station_id, "station_name": meta["station_name"],
            "location_id": meta["locationId"], "order_count": value[0],
            "total_kwh": rounded(value[1]), "total_fees": rounded(value[2]),
            "ranking_metric": "TOTAL_KWH"})
    manifests.append(write_dataset(out_dir, "station_top10_snapshot",
        ["start_date", "end_date", "rank_order", "station_id", "station_name", "location_id", "order_count", "total_kwh", "total_fees", "ranking_metric"],
        station_top10_rows, ["start_date", "end_date", "rank_order"],
        ["ncs_sim_dws.dws_order_station_daily", "ncs_sim_dwd.dwd_charging_station_meta"], ["period", "rank"] ))

    heatmap_rows = []
    for rank, (station_id, unused) in enumerate(ranked_stations[:8], 1):
        meta = station_by_id[station_id]
        for hour in range(24):
            value = station_hour_period.get((station_id, hour), [0, 0.0, 0.0])
            heatmap_rows.append({"start_date": start_date, "end_date": end_date,
                "station_rank": rank, "station_id": station_id, "station_name": meta["station_name"],
                "stat_hour": hour, "order_count": value[0], "total_kwh": rounded(value[1]),
                "total_fees": rounded(value[2]), "is_filled_zero": 0 if value[0] else 1})
    manifests.append(write_dataset(out_dir, "station_hour_heatmap_profile",
        ["start_date", "end_date", "station_rank", "station_id", "station_name", "stat_hour", "order_count", "total_kwh", "total_fees", "is_filled_zero"],
        heatmap_rows, ["start_date", "end_date", "station_rank", "stat_hour"],
        ["ncs_sim_dws.dws_order_station_hourly", "ncs_sim_dwd.dwd_charging_station_meta"], ["period", "top_station", "hour"] ))

    monthly_rows = []
    for month, value in sorted(monthly.items()):
        monthly_rows.append({"stat_month": month, "order_count": value[0],
            "total_kwh": rounded(value[1]), "total_fees": rounded(value[2]),
            "user_count": len(value[3]), "active_station_count": len(value[4])})
    manifests.append(write_dataset(out_dir, "revenue_monthly",
        ["stat_month", "order_count", "total_kwh", "total_fees", "user_count", "active_station_count"],
        monthly_rows, ["stat_month"], ["ncs_sim_ads.ads_revenue_monthly", "ncs_sim_dwd.dwd_charging_order"], ["month"] ))

    periods = sorted(monthly)
    current_period = periods[-1]
    previous_period = periods[-2] if len(periods) > 1 else None
    current = monthly[current_period]
    previous = monthly[previous_period] if previous_period else [0, 0.0, 0.0, set(), set()]
    comparison_values = [
        ("TOTAL_ORDERS", "Total orders", "order", current[0], previous[0]),
        ("TOTAL_KWH", "Total energy", "kWh", current[1], previous[1]),
        ("TOTAL_FEES", "Total charging fees", "CNY", current[2], previous[2]),
        ("TOTAL_USERS", "Total users", "user", len(current[3]), len(previous[3])),
        ("ACTIVE_STATIONS", "Active stations", "station", len(current[4]), len(previous[4])),
    ]
    kpi_comparison_rows = []
    for code, name, unit, current_value, previous_value in comparison_values:
        change = None if previous_value == 0 else rounded((current_value - previous_value) * 100.0 / previous_value)
        kpi_comparison_rows.append({"current_period": current_period,
            "previous_period": previous_period or "", "metric_code": code, "metric_name": name,
            "unit": unit, "current_value": rounded(current_value),
            "previous_value": rounded(previous_value), "change_pct": change})
    manifests.append(write_dataset(out_dir, "kpi_period_comparison",
        ["current_period", "previous_period", "metric_code", "metric_name", "unit", "current_value", "previous_value", "change_pct"],
        kpi_comparison_rows, ["current_period", "metric_code"],
        ["ncs_sim_ads.ads_monthly_comparison"], ["current_month", "metric"] ))

    station_rows = [{"station_id": x["stationId"], "location_id": x["locationId"],
                     "facility_type": x["facilityType"], "station_name": x["station_name"],
                     "address": x["address"], "device_count": x["device_count"],
                     "open_time": x["open_time"], "update_time": x["update_time"]}
                    for x in sorted(stations, key=lambda item: item["stationId"])]
    manifests.append(write_dataset(out_dir, "station_reference",
        ["station_id", "location_id", "facility_type", "station_name", "address", "device_count", "open_time", "update_time"],
        station_rows, ["station_id"], ["ncs_sim_dwd.dwd_charging_station_meta"], ["station"] ))

    duration_rows = [{"start_date": start_date, "end_date": end_date, "bucket_code": str(key),
                      "duration_bucket": value[0], "order_count": value[1],
                      "order_ratio": rounded(value[1] * 100.0 / total_orders)}
                     for key, value in sorted(duration.items())]
    manifests.append(write_dataset(out_dir, "duration_distribution",
        ["start_date", "end_date", "bucket_code", "duration_bucket", "order_count", "order_ratio"],
        duration_rows, ["start_date", "end_date", "bucket_code"], ["ncs_sim_ads.ads_duration_distribution"], ["period", "bucket"] ))

    weekday_rows = []
    for kind in ("workday", "weekend"):
        value = day_type[kind]
        weekday_rows.append({"start_date": start_date, "end_date": end_date, "day_type": kind,
            "order_count": value[0], "total_kwh": rounded(value[1]), "total_fees": rounded(value[2]),
            "avg_charge_hours": rounded(value[3] / value[0]) if value[0] else 0.0, "user_count": len(value[4]),
            "weekday_source": "SOURCE_WEEKDAY"})
    manifests.append(write_dataset(out_dir, "weekday_weekend_profile",
        ["start_date", "end_date", "day_type", "order_count", "total_kwh", "total_fees", "avg_charge_hours", "user_count", "weekday_source"],
        weekday_rows, ["start_date", "end_date", "day_type"], ["ncs_sim_ads.ads_workday_weekend"], ["period", "day_type"] ))

    weekday_hour_rows = []
    for (kind, hour), value in sorted(day_type_hour.items()):
        weekday_hour_rows.append({"start_date": start_date, "end_date": end_date,
            "day_type": kind, "stat_hour": hour, "order_count": value[0],
            "total_kwh": rounded(value[1]), "total_fees": rounded(value[2]),
            "avg_charge_hours": rounded(value[3] / value[0]) if value[0] else 0.0})
    manifests.append(write_dataset(out_dir, "weekday_hour_profile",
        ["start_date", "end_date", "day_type", "stat_hour", "order_count", "total_kwh", "total_fees", "avg_charge_hours"],
        weekday_hour_rows, ["start_date", "end_date", "day_type", "stat_hour"],
        ["ncs_sim_ads.ads_workday_hour_compare"], ["period", "day_type", "hour"] ))

    charge_type_rows = []
    for type_code, value in sorted(charge_type.items()):
        charge_type_rows.append({"start_date": start_date, "end_date": end_date,
            "facility_type": type_code, "charge_type": charge_type_name(type_code),
            "order_count": value[0], "order_ratio": rounded(value[0] * 100.0 / total_orders),
            "total_kwh": rounded(value[1]), "total_fees": rounded(value[2]),
            "avg_charge_hours": rounded(value[3] / value[0]) if value[0] else 0.0})
    manifests.append(write_dataset(out_dir, "charge_type_distribution",
        ["start_date", "end_date", "facility_type", "charge_type", "order_count", "order_ratio", "total_kwh", "total_fees", "avg_charge_hours"],
        charge_type_rows, ["start_date", "end_date", "facility_type"],
        ["ncs_sim_ads.ads_charge_type_stat"], ["period", "charge_type"] ))

    station_charge_type_rows = []
    for (station_id, type_code), value in sorted(station_charge_type.items()):
        station_charge_type_rows.append({"start_date": start_date, "end_date": end_date,
            "station_id": station_id, "station_name": station_by_id[station_id]["station_name"],
            "facility_type": type_code, "charge_type": charge_type_name(type_code),
            "order_count": value[0], "total_kwh": rounded(value[1]), "total_fees": rounded(value[2])})
    manifests.append(write_dataset(out_dir, "station_charge_type",
        ["start_date", "end_date", "station_id", "station_name", "facility_type", "charge_type", "order_count", "total_kwh", "total_fees"],
        station_charge_type_rows, ["start_date", "end_date", "station_id", "facility_type"],
        ["ncs_sim_ads.ads_station_type_cross"], ["period", "station", "charge_type"] ))

    station_hour_rows = []
    for (date, station_id, hour), value in sorted(station_hour_daily.items()):
        station_hour_rows.append({"data_date": date, "station_id": station_id,
            "station_name": station_by_id[station_id]["station_name"], "stat_hour": hour,
            "order_count": value[0], "total_kwh": rounded(value[1]), "total_fees": rounded(value[2])})
    manifests.append(write_dataset(out_dir, "station_hour_daily",
        ["data_date", "station_id", "station_name", "stat_hour", "order_count", "total_kwh", "total_fees"],
        station_hour_rows, ["data_date", "station_id", "stat_hour"], ["ncs_sim_dwd.dwd_charging_order", "ncs_sim_dwd.dwd_charging_station_meta"], ["date", "station", "hour"] ))

    process_daily = defaultdict(lambda: [0, set(), 0.0, None, None, 0.0, 0.0, 0.0])
    for row in processes:
        date = contract_time(order_by_session[row["esd"]]["created"]).strftime("%Y-%m-%d")
        soc, current, voltage, max_temp = f(row["soc"]), f(row["charge_current (A)"]), f(row["pack_voltage (V)"]), f(row["max_temperature (℃)"])
        value = process_daily[date]
        value[0] += 1; value[1].add(row["esd"]); value[2] += soc
        value[3] = soc if value[3] is None else max(value[3], soc)
        value[4] = soc if value[4] is None else min(value[4], soc)
        value[5] += current; value[6] += voltage; value[7] += max_temp
    process_rows = []
    for date, value in sorted(process_daily.items()):
        count = value[0]
        process_rows.append({"data_date": date, "record_count": count, "session_count": len(value[1]),
            "avg_soc": rounded(value[2] / count), "max_soc": rounded(value[3]), "min_soc": rounded(value[4]),
            "avg_current": rounded(value[5] / count), "avg_pack_voltage": rounded(value[6] / count),
            "avg_max_temperature": rounded(value[7] / count), "record_time_source": "ORDER_CREATED_INFERRED"})
    manifests.append(write_dataset(out_dir, "process_daily",
        ["data_date", "record_count", "session_count", "avg_soc", "max_soc", "min_soc", "avg_current", "avg_pack_voltage", "avg_max_temperature", "record_time_source"],
        process_rows, ["data_date"], ["ncs_sim_dws.dws_process_daily"], ["date"] ))

    process_count = len(processes)
    process_overview_rows = [{"start_date": start_date, "end_date": end_date,
        "record_count": process_count, "session_count": len({row["esd"] for row in processes}),
        "avg_soc": rounded(sum(f(row["soc"]) for row in processes) / process_count),
        "avg_temperature": rounded(sum((f(row["max_temperature (℃)"]) + f(row["min_temperature (℃)"])) / 2.0 for row in processes) / process_count),
        "avg_pack_voltage": rounded(sum(f(row["pack_voltage (V)"]) for row in processes) / process_count),
        "avg_current": rounded(sum(f(row["charge_current (A)"]) for row in processes) / process_count),
        "record_time_source": "ORDER_CREATED_INFERRED"}]
    manifests.append(write_dataset(out_dir, "process_overview",
        ["start_date", "end_date", "record_count", "session_count", "avg_soc", "avg_temperature", "avg_pack_voltage", "avg_current", "record_time_source"],
        process_overview_rows, ["start_date", "end_date"], ["ncs_sim_dwd.dwd_charging_process"], ["full_period"] ))

    first_hour, last_hour = min(logical_hour), max(logical_hour)
    hour_count = int((last_hour - first_hour).total_seconds() // 3600) + 1
    load_rows = []
    for offset in range(hour_count):
        hour = first_hour + timedelta(hours=offset)
        count, kwh = logical_hour.get(hour, [0, 0.0])
        load_rows.append({"stat_time": hour.strftime("%Y-%m-%d %H:00:00"), "total_kwh": round(kwh, 6),
                          "order_count": count, "is_observed": 1 if count else 0,
                          "fill_method": "NONE" if count else "ZERO", "time_quality": "UPSTREAM_FIXED_YEAR_2019",
                          "allocation_method": "DURATION_PRORATED"})
    manifests.append(write_dataset(out_dir, "load_hourly",
        ["stat_time", "total_kwh", "order_count", "is_observed", "fill_method", "time_quality", "allocation_method"],
        load_rows, ["stat_time"], ["ncs_sim_dwd.dwd_charging_order"], ["hour"] ))

    if sum(row["order_count"] for row in daily_rows) != total_orders:
        raise ValueError("日粒度订单对账失败")
    if sum(row["order_count"] for row in platform_rows) != total_orders:
        raise ValueError("平台订单对账失败")
    if sum(row["order_count"] for row in station_daily_rows) != total_orders:
        raise ValueError("站点日粒度订单对账失败")
    if sum(row["order_count"] for row in weekday_hour_rows) != total_orders:
        raise ValueError("工作日/周末×小时订单对账失败")
    if sum(row["order_count"] for row in charge_type_rows) != total_orders:
        raise ValueError("桩型订单对账失败")
    if sum(row["order_count"] for row in station_charge_type_rows) != total_orders:
        raise ValueError("站点×桩型订单对账失败")
    if len(station_top10_rows) != min(10, active_stations):
        raise ValueError("TOP10快照行数错误")
    if len(heatmap_rows) != min(8, active_stations) * 24:
        raise ValueError("热力图快照未形成站点×24小时完整矩阵")
    if abs(sum(row["total_kwh"] for row in load_rows) - rounded(total_kwh)) > 0.02:
        raise ValueError("小时负荷电量对账失败")

    generated = datetime.now(timezone(timedelta(hours=8))).isoformat()
    manifest = {
        "status": "SUCCESS", "schemaVersion": SCHEMA_VERSION,
        "metricVersion": METRIC_VERSION, "batchId": "ncs_sim_{}".format(run_id),
        "generatedAt": generated, "loadMode": "FULL_SNAPSHOT", "timezone": "Asia/Shanghai",
        "timeRule": "UPSTREAM_FIXED_YEAR_2019", "displayTimeRule": "UPSTREAM_FIXED_YEAR_2019",
        "modelTimeRule": "UPSTREAM_FIXED_YEAR_2019",
        "sourceWeekdayRule": "SOURCE_WEEKDAY",
        "cleaningPolicy": {
            "layer": "DWD_AND_DOWNSTREAM",
            "rawOrderCount": len(raw_orders), "validOrderCount": len(orders),
            "excludedOrderCount": len(raw_orders) - len(orders),
            "duplicateOrderCount": duplicate_count,
            "duplicateProcessCount": process_duplicate_count,
            "duplicateStationCount": station_duplicate_count,
            "rejectionReasonCounts": dict(sorted(rejection_counts.items())),
            "maxChargeHours": MAX_CHARGE_HOURS, "maxAveragePowerKw": MAX_AVG_POWER_KW,
            "positiveKwhZeroFeeCount": sum(1 for row in orders if f(row["kwhTotal"]) > 0 and f(row["charging_fees"]) == 0),
            "zeroFeeTreatment": "RETAIN_AS_MASKED_OR_MISSING; DO_NOT_IMPUTE",
            "rawDetailRetention": "ALL_ROWS_RETAINED_IN_ODS_AND_ML_RAW_FILES"
        },
        "datasets": manifests,
    }
    with open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8") as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2, sort_keys=True)
    print("PARTNER_OUTPUT_OK datasets={} total_orders={}".format(len(manifests), total_orders))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        print("PARTNER_OUTPUT_FAILED: {}".format(exc), file=sys.stderr)
        sys.exit(1)
