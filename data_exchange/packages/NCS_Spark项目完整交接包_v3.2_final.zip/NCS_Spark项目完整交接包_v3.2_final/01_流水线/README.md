# NCS Spark SQL 自动流水线 v2.7（上游时间口径统一版）

该目录把首次手工验证过的步骤封装成稳定接口。v2.5在ORC与多维分析基础上增加5个大屏即用数据集；v2.6增加虚拟机开机自启；v2.7将脱敏年份统一改为上游生成器规定的2019口径。原MySQL字段架构及机器学习接口保持不变。

## 上游接口

默认投递目录：

```text
/home/hadoop/inbound/sim/current/
```

必须同时存在：

```text
nvv2t.csv
dsv13r2.csv
nvv2t_md_end.csv
```

建议上游先上传到临时目录，三份文件全部完成后再整体替换 `current`，避免流水线读取上传中的文件。

## 部署

将整个目录上传到：

```text
/home/hadoop/ncs_hive_pipeline/
```

然后执行：

```bash
sed -i 's/\r$//' /home/hadoop/ncs_hive_pipeline/*.sh
chmod +x /home/hadoop/ncs_hive_pipeline/*.sh
mkdir -p /home/hadoop/inbound/sim/current
```

## 可以在哪些电脑运行

流水线是Linux Bash程序，不能在一台只安装Windows和PowerShell的电脑上直接执行Hive。推荐方式是：Windows只负责通过Xftp上传文件、通过SSH触发命令；实际计算始终在课程Linux虚拟机或Hadoop节点执行。

它可以复制到其他同类课程虚拟机运行，但目标环境必须具备：

- Bash、Java、Hadoop、Hive Metastore、Spark SQL以及Python 3；
- 当前账号能够读写Hive/HDFS表目录和本地输入输出目录；
- Hadoop相关进程已经启动；
- 三份输入CSV符合本项目字段契约。

安装位置不再要求固定为 `/home/hadoop/ncs_hive_pipeline`，脚本会自动识别自身目录。默认数据路径仍保持与当前项目一致；其他电脑可修改 `config.env`，或在调用时用环境变量覆盖：

```bash
INBOUND_DIR=/data/ncs/inbound \
LOAD_DIR=/data/ncs/work \
OUTPUT_DIR=/data/ncs/output \
bash /任意安装目录/hive_pipeline/run_pipeline.sh
```

若目标电脑是多节点集群的客户端，本机不一定运行全部守护进程，可以在 `config.env` 调整 `REQUIRED_DAEMONS`。这只改变启动前检查，不会替代真正的Hadoop/Hive服务。

## 手动触发一次

```bash
bash /home/hadoop/ncs_hive_pipeline/run_pipeline.sh
```

这是一条命令，不需要逐条执行 Hive SQL。

默认执行引擎为Spark SQL，并通过YARN运行。可以先确认：

```bash
spark-sql --version
```

运行中的YARN任务名称以 `ncs-spark-pipeline-<运行批次>` 开头，便于使用 `yarn application -list` 查看进度。

如Spark环境临时不可用，可显式回退到已经验证的Hive on MapReduce基线：

```bash
SQL_ENGINE=hive bash /home/hadoop/ncs_hive_pipeline/run_pipeline.sh
```

回退只更换执行器，不改变SQL、输入和输出合同。

## 性能优化

当前版本针对课程镜像的小批量数据做了以下优化：

- ODS导入、DWD清洗、DWS/ADS聚合和15项内部校验导出被拼成一次完整Spark SQL会话。
- `01_sim_create.hql` 和一次性ORC迁移脚本默认只在首次部署/升级时并入批处理，整轮成功后写入 `state/schema_initialized_v24_orc` 标记；后续轮次跳过重复建表。
- 15个内部兼容/扩展指标通过一个带边界标记的结果流输出，不再为每个文件另启计算作业。
- 机器学习连续小时序列直接从已经通过输入契约校验的订单CSV生成，不再额外启动Hive小时聚合作业。
- 移除建表展示和各层中间 `COUNT` 查询；最终校验器仍核对所有正式输出和关键总量。
- SQL计算默认使用Spark on YARN，并启用自适应执行；小数据集默认4个shuffle分区，减少MapReduce逐作业启动开销。
- DWD显式过滤三份CSV的表头记录，不依赖Spark对Hive `skip.header.line.count` 的兼容行为；这保证Spark与Hive统计口径一致。

日志会打印输入校验、完整SQL批处理、文件归集和输出校验的 `elapsed=...s`。若再次修改表结构，可删除 `state/schema_initialized_v24_orc` 后再运行；也可在 `config.env` 中把 `INITIALIZE_SCHEMA` 临时改为 `always`。

优化不会跳过数据清洗、聚合或15个文件的完整校验。第一次升级运行会把可重建的DWD/DWS/ADS表迁移为ORC，因此通常比后续运行略慢；ODS原始表不受影响。

node100正式上游回归（2026-09-14）：Spark SQL阶段207秒，模型输出2秒，10个合同数据集生成3秒，统一校验2秒，全流程218秒；订单5000、过程记录2328、站点105、连续小时16872，原子发布成功。

node100 v2.5回归（2026-09-14 19:30）：Spark SQL阶段217秒，15项内部指标导出成功，模型输出1秒，18个合同数据集生成2秒，统一校验1秒，全流程224秒；订单5000、过程2328、连续小时16872、补零14733，原子发布成功。相比v2.3仅增加6秒（约2.8%）。

## 自动检测变化

执行：

```bash
bash /home/hadoop/ncs_hive_pipeline/run_if_changed.sh
```

脚本通过三份文件的 SHA-256 判断数据是否变化。只有输入变化且上一轮成功后才记录新版本。

需要定时自动运行时，由具备 crontab 权限的成员添加：

```text
*/5 * * * * /bin/bash /home/hadoop/ncs_hive_pipeline/run_if_changed.sh
```

这表示每5分钟检查一次。它是自动批处理，不是毫秒级实时流处理。

## 虚拟机开机自动运行

v2.7保留systemd开机服务。首次上传到 `/home/hadoop/ncs_spark_v27/` 后只安装一次：

```bash
bash /home/hadoop/ncs_spark_v27/hive_pipeline/install_autostart.sh
```

以后启动虚拟机后，系统自动检查并启动HDFS、YARN和Hive Metastore，等待服务就绪，再检测三份上游CSV。数据发生变化或正式输出缺失时运行Spark；输入未变化且已有成功输出时直接复用，避免每次开机重复计算。后台默认每60秒检查一次变化。

查看状态：

```bash
bash /home/hadoop/ncs_spark_v27/hive_pipeline/status_autostart.sh
```

Windows用户可以双击包根目录的 `安装虚拟机开机自启.cmd` 完成首次安装，之后双击 `查看虚拟机运行状态.cmd` 查看结果。首次安装需要SSH登录密码和sudo权限。该服务只负责Hadoop/YARN/Hive Metastore和数据流水线；Flask、Vue及机器学习服务仍由相应伙伴配置。

## 下游接口

## 数据清洗口径

原始三份CSV和ODS层完整保留，方便追溯；DWD、DWS、ADS、大屏指标和机器学习
`history.csv` 统一只使用业务有效订单。以下记录会从清洗层及其下游剔除：

- `kwhTotal <= 0`；
- `chargeTimeHrs <= 0` 或大于24小时；
- 平均功率 `kwhTotal / chargeTimeHrs > 120kW`；
- `ended < created`（0014/0015按上游约定映射到2019后比较）。

与被剔除订单关联的过程监测记录也不进入DWD和训练视图。费用为0但电量正常的
订单不直接删除：该字段可能脱敏或缺失，流水线保留记录、禁止虚构费用，并在
`contract_v2/manifest.json` 的 `cleaningPolicy` 中报告数量和剔除原因。

同一 `sessionId` 出现多行时，ODS继续保留原始行；DWD先排除业务异常，再按关键字段完整度、结束时间、开始时间和电量依次择优保留一条。去重数量写入日志和合同manifest。

机器学习与大屏负荷曲线不再把整笔订单电量堆到开始小时。流水线用
`kwhTotal / chargeTimeHrs` 计算订单平均功率，再按订单在每个自然小时实际覆盖的秒数分摊，保证分摊前后总电量守恒。订单次数分布仍按开始小时统计。

为对应教学验收，DWD额外生成一次完整充电粒度的宽表
`ncs_sim_dwd.dwd_charge_detail`，并以此生成五张DWS主题表：
`dws_station_agg`、`dws_user_agg`、`dws_hour_agg`、`dws_dim_agg`、`dws_bms_agg`。

成功结果固定发布到：

```text
/home/hadoop/dashboard/sim_data/
```

目录中包含15个无表头TSV文件和 `manifest.json`。除原12项外，新增 `workday_hour_compare.csv`、`charge_type_stat.csv` 和 `station_type_cross.csv`。只有全部Spark SQL步骤和输出校验通过后才替换该目录；失败时保留上一版有效结果。

为兼容 MySQL 伙伴的新合同，同一次成功发布还会生成：

```text
/home/hadoop/dashboard/sim_data/contract_v2/
```

该目录保留原10个带表头 UTF-8-SIG CSV，增加3个多维对比数据集和5个大屏即用快照，共18个合同数据集。原10张MySQL表结构不变，只需新增扩展表。默认TOP10固定按充电量排序，默认热力图固定8站×24小时并补0。独立 `manifest.json` 记录批次、版本、时区、粒度、主键、行数和 SHA-256。这些文件由 Python 从已通过校验的输入生成，不增加分布式计算作业。

机器学习导入快照发布在子目录：

```text
/home/hadoop/dashboard/sim_data/ml/
```

其中：

- `history.csv`：带 `ts,kwh` 表头的连续小时全网负荷，缺失小时补0且不少于512行，用于MySQL导入对账和回归备用；
- `nvv2t_new.csv`：UTF-8-SIG、带原22列表头，原始脱敏年份保持不变，用于导入MySQL订单重训表；
- `dsv13r2_new.csv`：UTF-8-SIG、带原11列表头，`record_time` 已按关联订单修复为13位毫秒时间戳，用于导入MySQL过程重训表。

同时生成 `nvv2t.csv` 和 `dsv13r2.csv` 兼容别名，内容分别与两个 `*_new.csv` 完全一致，用于对接《交接包(2)》的文件命名。

`manifest.json` 同时记录大屏/MySQL与机器学习导入快照的校验结果。模型本身不在Hive虚拟机自动重训。正式集成时，MySQL先导入这些快照，机器学习伙伴从 `ml_history_v1`、`ml_order_training_v1` 和 `ml_process_training_v1` 读取，再将预测写回 `ml_forecast_hourly_v1`。CSV只用于MySQL导入、回归和故障备用。

MySQL伙伴可以定时检查 `manifest.json`，或由集成调度程序在流水线成功后触发导入。

## 失败处理

- 输入不符合契约时立即停止，不运行Hive。
- 缺少Hadoop核心进程时立即停止。
- Hive任一步返回非零状态时立即停止。
- 输出文件为空、字段数错误或汇总不一致时停止发布。
- 日志位于 `/home/hadoop/ncs_hive_pipeline/logs/`。
- 上一版结果被移动到带时间戳的 `sim_data.previous.*` 目录，可回滚。
